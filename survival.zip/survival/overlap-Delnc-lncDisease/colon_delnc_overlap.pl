#!/usr/bin/perl -w
use strict;
use warnings;
###################################################################################################
#思路：	将colon相关的gene name和delnc中的lncRNA取交集
		#1.计算差异lnc的genename，将差异lnc和gencode读入，取overlap存起来
		#2.计算差异基因和colon的overlap
###################################################################################################


open DELNC,"model.txt" or die "Can't open DELNC";
my $count=0;
my @delnc;
while(<DELNC>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$delnc[$count][0]=$temp[0];
	#print "$delnc[$count][0]\t$delnc[$count][1]\n";
	$count=$count+1;
	
}
close(DELNC);

open GENCODE,"gencode.txt" or die "Can't open GENCODE";		
$count=0;
my @gencode;
while(<GENCODE>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$gencode[$count][0]=$temp[0];
	$gencode[$count][1]=$temp[1];
	#print $gencode_cor[$count][0];
	$count=$count+1;
}
close(GENCODE);


$count=0;
my @delnc_name;
#取差异lnc和gencode的overlap
for my $i (0 .. $#delnc)
{
	for my $j (0 .. $#gencode)
	{
		if($delnc[$i][0] eq $gencode[$j][0])
		{
			#print RESULT "$delnc[$j][0]\t$delnc[$j][1]\n";
			#print "$gencode[$i][0]\t$gencode[$i][1]\n";
			$delnc_name[$count][0]=$gencode[$j][0];
			$delnc_name[$count][1]=$gencode[$j][1];
			#print "$delnc_name[$count][0]: $count\n";
			$count=$count+1;
			
			last;
		}
	}
}
print "count is: $#delnc_name\n";




open COLON,"colon-pre.txt" or die "Can't open COLON";		
$count=0;
my @colon_cor;
while(<COLON>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$colon_cor[$count][0]=$temp[0];
	#print $colon_cor[$count][0];

	$count=$count+1;
	#print "\n";
}
close(COLON);


#print "$#colon_cor\n";
#print "$#delnc_name";

#取delnc_name和colon的overlap
$count=0;
#计算overlap
for my $i (0 .. $#colon_cor)
{
	for my $j (0 .. $#delnc_name)
	{
		if($colon_cor[$i][0] eq $delnc_name[$j][1])
		{
			#print RESULT "$delnc[$j][0]\t$delnc[$j][1]\n";
			print "$j:	$delnc_name[$j][0]\t$delnc_name[$j][1]\n";
			$count=$count+1;
			last;
		}
	}
}

print "overlap count is: $count\n";

