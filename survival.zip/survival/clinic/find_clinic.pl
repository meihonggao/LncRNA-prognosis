#!/usr/bin/perl -w
use strict;
use warnings;
###################################################################################################
#思路：	1.将tumor_sample_id读入
#		2.将clinic读入
#	    3.计算overlap信息并输出
###################################################################################################



open COAD_SAMPLE,"tumor_sample_id.txt" or die "Can't open COAD_SAMPLE";	
my $count=0;
my @coad_sample;
while(<COAD_SAMPLE>)
{
	my @temp=split /\s+/, $_ ;
	$coad_sample[$count]=$temp[0];
	$count=$count+1;
}
close(COAD_SAMPLE);


open RESULT,">clinical_true_position_need_final.txt" or die "Can't open RESULT";
my $flag=0;
for my $i (0 .. $#coad_sample)
{
	print "sample:$i\n";
	open COAD_CLINIC,"clinical_true_position_need.tsv" or die "Can't open COAD_CLINIC";	
	my @coad_clinic;
	$count=0;
	
	while(<COAD_CLINIC>)
	{
		#print "count:$count\n";
		my @temp=split /\t/, $_ ;
		if(($count==0)&&($flag==0))
		{
			$flag=1;
			print RESULT "$_";
		}
		else
		{
			#print "******************\n";
			#print "$coad_sample[$i]\n";
			#print "$temp[1]\n";
			#print "******************\n\n";
			if($coad_sample[$i] eq $temp[1])
			{
				print "haha\n";
				print RESULT "$_";
				last;
			}
		}
		$count=$count+1;
	}
	close(COAD_CLINIC);
}

close(RESULT);