###########################################准备矩阵数据#################################################################
setwd("C:\\Users\\gmh\\Desktop\\LncRNA分析\\project\\LncRNA\\COX\\COAD\\no_validation");

final_express <- read.table(file = "lnc_clinic_express3.txt", sep = "\t", header = TRUE, row.names = 1, stringsAsFactors = TRUE);
final_express=t(final_express)	
final_express2=matrix(,nrow(final_express),ncol(final_express)+1)
rownames(final_express2)=rownames(final_express)
colnames(final_express2)=c(colnames(final_express),"os_time")

final_express2[,1:ncol(final_express)]=final_express[,1:ncol(final_express)]
for(i in 1:nrow(final_express))	#compute os_time
{
	if(final_express[i,"vital_status"]==1)	#vital_status is Alive,survival time is equals to days_to_last_follow_up
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_last_follow_up"]
		#final_express$os_time[i]=final_express$days_to_last_follow_up[i]
	}
	else	#状态为Dead,生存时间为days_to_death
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_death"]
	}
}

final_express2[,"os_time"]=final_express2[,"os_time"]/365
final_express2=as.data.frame(final_express2)
#head(final_express2)

###########################################Cox单因素分析差异分析#################################################################
library("survival")
library("survminer")
#批量进行单因素Cox生存分析
covariates <- colnames(final_express2)
temp1= which(covariates =="os_time")   
temp2= which(covariates =="vital_status")        
covariates = covariates[-temp1]
covariates = covariates[-temp2]


univ_formulas <- sapply(covariates,function(x) as.formula(paste('Surv(os_time, vital_status)~', x)))
univ_models <- lapply( univ_formulas, function(x){coxph(x, data = final_express2)})

# Extract data 
univ_results <- lapply(univ_models,
                       function(x){ 
                         x <- summary(x)
                         p.value<-signif(x$wald["pvalue"], digits=2)
                         wald.test<-signif(x$wald["test"], digits=2)
                         beta<-signif(x$coef[1], digits=2);#coeficient beta
                         HR <-signif(x$coef[2], digits=2);#exp(beta)
                         HR.confint.lower <- signif(x$conf.int[,"lower .95"], 2)
                         HR.confint.upper <- signif(x$conf.int[,"upper .95"],2)
                         HR <- paste0(HR, " (", 
                                      HR.confint.lower, "-", HR.confint.upper, ")")
                         res<-c(beta, HR, wald.test, p.value)
                         names(res)<-c("beta", "HR (95% CI for HR)", "wald.test", 
                                       "p.value")
                         return(res)
                         #return(exp(cbind(coef(x),confint(x))))
                       })
#as.data.frame(univ_results)
res <- t(as.data.frame(univ_results, check.names = FALSE))
res2=res
res2=res2[which(abs(as.numeric(res2[,"p.value"]))<0.01),] 

#
#ENSG00000205037.2      "0.0025"   "1 (1-1)"          "6.5"     "0.011"  
#ENSG00000231768.1      "0.004"    "1 (1-1)"          "5.3"     "0.022"  
#ENSG00000235532.1      "0.0024"   "1 (1-1)"          "6.7"     "0.0098" 
#ENSG00000236333.3      "0.0015"   "1 (1-1)"          "6.8"     "0.0093" 
#ENSG00000272143.1      "0.0011"   "1 (1-1)"          "5"       "0.025"  
#ENSG00000205056.8      "0.0014"   "1 (1-1)"          "4.2"     "0.04"   
#ENSG00000246334.2      "0.00089"  "1 (1-1)"          "5.3"     "0.021"  
#ENSG00000267480.1      "-0.001"   "1 (1-1)"          "4.1"     "0.043"  
#ENSG00000233117.2      "3e-04"    "1 (1-1)"          "10"      "0.0015" 
#ENSG00000240219.1      "0.0017"   "1 (1-1)"          "15"      "0.00011"
#ENSG00000258077.2      "0.001"    "1 (1-1)"          "4.2"     "0.04"   
#ENSG00000224272.2      "-0.00014" "1 (1-1)"          "5.8"     "0.016"  
#ENSG00000253405.1      "0.00034"  "1 (1-1)"          "17"      "4.8e-05"
#days_to_death          "0.00066"  "1 (1-1)"          "37"      "1.1e-09"
#age_at_index           "0.031"    "1 (1-1.1)"        "11"      "0.00072"
#tumor_stage            "0.59"     "1.8 (1.5-2.2)"    "37"      "1.2e-09"
#days_to_last_follow_up "-0.0027"  "1 (1-1)"          "98"      "4.5e-23


ENSG00000235532.1      "0.0024"  "1 (1-1)"          "6.7"     "0.0098" 
ENSG00000236333.3      "0.0015"  "1 (1-1)"          "6.8"     "0.0093" 
ENSG00000233117.2      "3e-04"   "1 (1-1)"          "10"      "0.0015" 
ENSG00000240219.1      "0.0017"  "1 (1-1)"          "15"      "0.00011"
ENSG00000253405.1      "0.00034" "1 (1-1)"          "17"      "4.8e-05"




###########################################Cox单因素分析差异分析#################################################################




###########################################Cox多因素分析差异分析#################################################################

multi_res<- coxph(Surv(os_time, vital_status) ~ ENSG00000235532.1+
ENSG00000236333.3+ENSG00000233117.2+ENSG00000240219.1+ENSG00000253405.1, data = final_express2)
#multi_res

#多因素分析结果
#                        coef  exp(coef)   se(coef)      z        p
#ENSG00000205037.2 -4.968e-04  9.995e-01  1.610e-03 -0.309 0.757692		13
#ENSG00000231768.1 -2.672e-03  9.973e-01  3.196e-03 -0.836 0.403105		11
#ENSG00000235532.1  3.329e-03  1.003e+00  2.007e-03  1.659 0.097110		7
#ENSG00000236333.3  9.738e-04  1.001e+00  8.075e-04  1.206 0.227849		10
#ENSG00000272143.1  1.357e-03  1.001e+00  6.297e-04  2.156 0.031121		3
#ENSG00000205056.8 -9.200e-04  9.991e-01  1.411e-03 -0.652 0.514524		12
#ENSG00000246334.2  9.030e-04  1.001e+00  4.085e-04  2.211 0.027048		2
#ENSG00000267480.1 -6.373e-04  9.994e-01  4.822e-04 -1.322 0.186266		9
#ENSG00000233117.2  3.456e-04  1.000e+00  1.783e-04  1.939 0.052553		4
#ENSG00000240219.1  1.021e-03  1.001e+00  5.304e-04  1.925 0.054177		5
#ENSG00000258077.2  9.631e-04  1.001e+00  5.225e-04  1.843 0.065305		6
#ENSG00000224272.2 -9.022e-05  9.999e-01  6.086e-05 -1.482 0.138270		8
#ENSG00000253405.1  3.465e-04  1.000e+00  9.265e-05  3.740 0.000184		1

#Likelihood ratio test=42.99  on 13 df, p=4.505e-05
#n= 447, number of events= 98 

ENSG00000235532.1 1.548e-03 1.002e+00 1.085e-03 1.427  0.15370
ENSG00000236333.3 1.058e-03 1.001e+00 6.892e-04 1.534  0.12491
ENSG00000233117.2 2.539e-04 1.000e+00 1.134e-04 2.239  0.02513
ENSG00000240219.1 1.569e-03 1.002e+00 4.772e-04 3.288  0.00101
ENSG00000253405.1 3.605e-04 1.000e+00 8.143e-05 4.427 9.58e-06

###########################################Cox多因素分析差异分析#################################################################
###########################################计算每个样本的risk_score和risk_level#################################################################
score_express=matrix(,nrow(final_express2),7)
rownames(score_express)=rownames(final_express2)
colnames(score_express)=c("ENSG00000253405.1","ENSG00000240219.1","ENSG00000233117.2","os_time","vital_status","risk_score","risk_level")
score_express[,1]=final_express2[,"ENSG00000253405.1"]
score_express[,2]=final_express2[,"ENSG00000240219.1"]
score_express[,3]=final_express2[,"ENSG00000233117.2"]
score_express[,4]=final_express2[,"os_time"]
score_express[,5]=final_express2[,"vital_status"]
for(i in 1:nrow(score_express))
{
	score_express[i,"risk_score"]=0.0003605*score_express[i,1]+0.001569*score_express[i,2]+0.0002539*score_express[i,3]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express))
{
	if(score_express[i,"risk_score"]<=cutt_off)
	{
		score_express[i,"risk_level"]=1 
	}
	else
	{
		score_express[i,"risk_level"]=2
	}
}

###########################################计算每个样本的risk_score和risk_level#################################################################
###########################################计算每个样本的risk_level绘制生存曲线#################################################################
score_express=as.data.frame(score_express)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express)
ggsurvplot(fit, data = score_express,
surv.median.line = "hv", # Add medians survival
legend.title = "risk level",
legend.labs = c("low", "high"),
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )

###########################################计算每个样本的risk_level绘制生存曲线#################################################################





###########################################计算每个样本的risk_score和risk_level#################################################################
score_express=matrix(,nrow(final_express2),13)
rownames(score_express)=rownames(final_express2)
colnames(score_express)=c("ENSG00000253405.1","ENSG00000246334.2","ENSG00000272143.1","ENSG00000233117.2","ENSG00000240219.1","ENSG00000258077.2"
,"ENSG00000235532.1","ENSG00000224272.2","ENSG00000267480.1","os_time","vital_status","risk_score","risk_level")
score_express[,1]=final_express2[,"ENSG00000253405.1"]
score_express[,2]=final_express2[,"ENSG00000246334.2"]
score_express[,3]=final_express2[,"ENSG00000272143.1"]
score_express[,4]=final_express2[,"ENSG00000233117.2"]
score_express[,5]=final_express2[,"ENSG00000240219.1"]
score_express[,6]=final_express2[,"ENSG00000258077.2"]
score_express[,7]=final_express2[,"ENSG00000235532.1"]
score_express[,8]=final_express2[,"ENSG00000224272.2"]
score_express[,9]=final_express2[,"ENSG00000267480.1"]
score_express[,10]=final_express2[,"os_time"]
score_express[,11]=final_express2[,"vital_status"]
for(i in 1:nrow(score_express))
{
	score_express[i,"risk_score"]=0.0003465*score_express[i,1]+0.000903*score_express[i,2]+0.001357*score_express[i,3]
	+0.0003456*score_express[i,4]+0.001021*score_express[i,5]+0.0009631*score_express[i,6]+0.003329*score_express[i,7]
	+(-0.00009022)*score_express[i,8]+(-0.0006373)*score_express[i,9]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express))
{
	if(score_express[i,"risk_score"]<=cutt_off)
	{
		score_express[i,"risk_level"]=1 
	}
	else
	{
		score_express[i,"risk_level"]=2
	}
}

###########################################计算每个样本的risk_score和risk_level#################################################################
###########################################计算每个样本的risk_level绘制生存曲线#################################################################
score_express=as.data.frame(score_express)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express)
ggsurvplot(fit, data = score_express,
surv.median.line = "hv", # Add medians survival
legend.title = "risk level",
legend.labs = c("low", "high"),
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )

###########################################计算每个样本的risk_level绘制生存曲线#################################################################




###########################################计算每个样本的risk_score和risk_level#################################################################
score_express=matrix(,nrow(final_express2),13)
rownames(score_express)=rownames(final_express2)
colnames(score_express)=c("ENSG00000235532.1","ENSG00000272143.1","ENSG00000246334.2",
"ENSG00000267480.1","ENSG00000233117.2","ENSG00000240219.1",
"ENSG00000258077.2","ENSG00000224272.2","ENSG00000253405.1","os_time","vital_status","risk_score","risk_level")
score_express[,1]=final_express2[,"ENSG00000235532.1"]
score_express[,2]=final_express2[,"ENSG00000272143.1"]
score_express[,3]=final_express2[,"ENSG00000246334.2"]
score_express[,4]=final_express2[,"ENSG00000267480.1"]
score_express[,5]=final_express2[,"ENSG00000233117.2"]
score_express[,6]=final_express2[,"ENSG00000240219.1"]	
score_express[,7]=final_express2[,"ENSG00000258077.2"]
score_express[,8]=final_express2[,"ENSG00000224272.2"]
score_express[,9]=final_express2[,"ENSG00000253405.1"]
score_express[,10]=final_express2[,"os_time"]
score_express[,11]=final_express2[,"vital_status"]
for(i in 1:nrow(score_express))
{
	score_express[i,"risk_score"]=0.003329*score_express[i,1]+0.001357*score_express[i,2]+0.000903*score_express[i,3]
	+(-0.0006373)*score_express[i,4]+0.0003456*score_express[i,5]+0.001021*score_express[i,6]
	+0.0009631*score_express[i,7]+(-0.00009022)*score_express[i,8]+0.0003465*score_express[i,9]

}

#cutt_off为risk_score的中位数
cutt_off=median(score_express[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express))
{
	if(score_express[i,"risk_score"]<=cutt_off)
	{
		score_express[i,"risk_level"]=1 
	}
	else
	{
		score_express[i,"risk_level"]=2
	}
}

###########################################计算每个样本的risk_score和risk_level#################################################################



###########################################计算每个样本的risk_level绘制生存曲线#################################################################
score_express=as.data.frame(score_express)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express)
ggsurvplot(fit, data = score_express,
surv.median.line = "hv", # Add medians survival
legend.title = "risk level",
legend.labs = c("low", "high"),
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )

###########################################计算每个样本的risk_level绘制生存曲线#################################################################



###########################################绘制生存曲线#################################################################
#1.简单绘制
res.cox <- coxph(Surv(os_time, vital_status) ~ ENSG00000259834.1+ENSG00000265519.1+ENSG00000253929.1+ENSG00000167912.5+ENSG00000271824.1+ENSG00000253405.1, data =  final_express2)
fit2<- survfit(Surv(os_time, vital_status) ~ gender, data = final_express2)
# Basic survival curves
ggsurvplot(fit, data = final_express2)


#2.进阶版
ggsurvplot(fit, data = final_express2,
 surv.median.line = "hv", # Add medians survival
 # Change legends: title & labels
 legend.title = "Sex",
 legend.labs = c("Male", "Female"),
 # Add p-value and tervals
 pval = TRUE,
 conf.int = TRUE,
 # Add risk table
 risk.table = TRUE,
 tables.height = 0.2,tables.theme = theme_cleantable(),
 # Color palettes. Use custom color: c("#E7B800", "#2E9FDF"),
 # or brewer color (e.g.: "Dark2"), or ggsci color (e.g.: "jco")
 palette = c("#E7B800", "#2E9FDF"),
 ggtheme = theme_bw() # Change ggplot2 theme
)

#3.Change font size, style and color
ggsurvplot(fit, data = final_express2,  main = "Survival curve",
   font.main = c(16, "bold", "darkblue"),
   font.x = c(14, "bold.italic", "red"),
   font.y = c(14, "bold.italic", "darkred"),
   font.tickslab = c(12, "plain", "darkgreen"))

###########################################绘制生存曲线#################################################################
