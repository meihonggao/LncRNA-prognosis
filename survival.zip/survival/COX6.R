###########################################准备矩阵数据#################################################################
setwd("C:\\Users\\gmh\\Desktop\\LncRNA分析\\project\\LncRNA\\RSF");
final_express <- read.table(file = "lnc_clinic_express3.txt", sep = "\t", header = TRUE, row.names = 1, stringsAsFactors = TRUE);
final_express=t(final_express)	
final_express2=matrix(,nrow(final_express),ncol(final_express)+1)
rownames(final_express2)=rownames(final_express)
colnames(final_express2)=c(colnames(final_express),"os_time")

final_express2[,1:ncol(final_express)]=final_express[,1:ncol(final_express)]
for(i in 1:nrow(final_express))	#compute os_time
{
	if(final_express[i,"vital_status"]==1)	#vital_status is Alive,survival time is equals to days_to_last_follow_up
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_last_follow_up"]
		#final_express$os_time[i]=final_express$days_to_last_follow_up[i]
	}
	else	#状态为Dead,生存时间为days_to_death
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_death"]
	}
}

#将生存时间过小的样本过滤掉
cutoff_time=10
off_sample_name=c()
for(i in 1:nrow(final_express2))
{
	if((final_express2[i,"os_time"]<=cutoff_time)||(final_express2[i,"tumor_stage"]==5))
	{
		off_sample_name=c(off_sample_name,rownames(final_express2)[i])
		print(rownames(final_express2)[i])
	}
}

final_express2=final_express2[!rownames(final_express2) %in% off_sample_name , ]	#447====》411

final_express2[,"os_time"]=final_express2[,"os_time"]/365		#将生存时间转换为年

#在411个样本中，选取246个为训练集，剩余165个位测试集
final_express3=as.data.frame(final_express2)
median_age=median(final_express3[,"age_at_index"])
for(i in 1:nrow(final_express3))
{
	
	
	if(final_express3[i,"vital_status"]==1)
	{
		final_express3[i,"vital_status"]="Alive"
	}
	else
	{
		final_express3[i,"vital_status"]="Dead"
	}
	if(final_express3[i,"gender"]==1)
	{
		final_express3[i,"gender"]="male"
	}
	else
	{
		final_express3[i,"gender"]="female"
	}
	if(final_express3[i,"age_at_index"]<median_age)
	{
		final_express3[i,"age_at_index"]="young"
	}
	else
	{
		final_express3[i,"age_at_index"]="old"
	}
	
	if((final_express3[i,"tumor_stage"]==1)||(final_express3[i,"tumor_stage"]==2))
	{
		final_express3[i,"tumor_stage"]="early"
	}
	if((final_express3[i,"tumor_stage"]==3)||(final_express3[i,"tumor_stage"]==4))
	{
		final_express3[i,"tumor_stage"]="late"
	}
	if(final_express3[i,"tumor_stage"]==5)
	{
		final_express3[i,"tumor_stage"]="not_reported"
	}
	
	
}
for(i in 1:nrow(final_express2))
{
	if(final_express2[i,"vital_status"]==2)
	{
		final_express2[i,"vital_status"]=0
	}
}



###############################################随机生存森林RSF分析###############################################
data_express=final_express2	#为了保证gender等字段是数字
data_express=as.data.frame(data_express)		#411个样本
v.obj2 <- rfsrc(Surv(os_time, vital_status) ~ ., data = data_express, ntree = 100,block.size = 1)	#nodesize》=20时，结果不太好

## print and plot the grow object
print(v.obj2)
plot(v.obj2)
v.obj$topvars


## plot survival curves for first 10 individuals -- direct way
matplot(v.obj2$time.interest, 100 * t(v.obj2$survival.oob[1:10, ]),
    xlab = "Time", ylab = "Survival", type = "l", lty = 1)


## plot survival curves for first 10 individuals
## using function "plot.survival" 
plot.survival(v.obj2, subset = 1:10)



## fast nodesize optimization for data_express
## optimal nodesize in survival is larger than other families
## see the function "tune" for more examples
tune.nodesize(Surv(os_time,vital_status) ~ ., data_express)

our.rf=var.select(object=v.obj2,vdv,method="vh.vimp",nrep=50)
our.rf$topvars
###############################################随机生存森林RSF分析###############################################



###############################################多因素COX分析###############################################
#  ENSG00000229228.1       24
#  ENSG00000250073.2       20
#  ENSG00000256139.2       20

multi_res2<- coxph(Surv(os_time, vital_status) ~ENSG00000214888.2+ENSG00000224968.1+ENSG00000265356.1+ENSG00000264016.2
+ENSG00000260719.1+ENSG00000250073.2+ENSG00000231768.1+ENSG00000205056.8
+ENSG00000237807.3+ENSG00000225986.1+ENSG00000240219.1+ENSG00000267194.1
+ENSG00000259834.1+ENSG00000253929.1+ENSG00000167912.5+ENSG00000253405.1
+ENSG00000229228.1+ENSG00000256139.2
, data = as.data.frame(final_express2))

#name	coef	exp(coef)	se(coef)	z	p
#ENSG00000253405.1	4.23E-04	1.00E+00	9.03E-05	4.689	2.75E-06
#ENSG00000265356.1	1.54E-02	1.02E+00	4.83E-03	3.183	0.00146
#ENSG00000264016.2	-9.70E-03	9.90E-01	3.24E-03	-2.991	0.00278
#ENSG00000260719.1	7.51E-03	1.01E+00	2.60E-03	2.892	0.00382
#ENSG00000259834.1	-1.31E-03	9.99E-01	4.90E-04	-2.681	0.00733
#ENSG00000231768.1	6.64E-03	1.01E+00	2.53E-03	2.624	0.0087
#ENSG00000240219.1	2.03E-03	1.00E+00	9.70E-04	2.096	0.0361
#ENSG00000205056.8	1.84E-03	1.00E+00	8.83E-04	2.088	0.03678
#ENSG00000167912.5	-4.36E-04	1.00E+00	2.38E-04	-1.835	0.06655
#ENSG00000250073.2	8.97E-04	1.00E+00	5.04E-04	1.782	0.0747
#ENSG00000214888.2	4.57E-03	1.01E+00	2.85E-03	1.602	0.10905
#ENSG00000225986.1	-1.21E-03	9.99E-01	9.05E-04	-1.337	0.18121
#ENSG00000267194.1	-5.66E-05	1.00E+00	4.95E-05	-1.142	0.25352
#ENSG00000224968.1	2.03E-03	1.00E+00	3.09E-03	0.656	0.51169
#ENSG00000256139.2	6.25E-04	1.00E+00	1.18E-03	0.53	0.59624
#ENSG00000253929.1	-6.94E-05	1.00E+00	1.34E-04	-0.517	0.6052
#ENSG00000229228.1	2.39E-04	1.00E+00	4.51E-03	0.053	0.95778
#ENSG00000237807.3	6.11E-06	1.00E+00	1.85E-04	0.033	0.9737


#Likelihood ratio test=63.71  on 18 df, p=5.074e-07
#n= 411, number of events= 84 
###############################################多因素COX分析###############################################
score_express2=matrix(,nrow(final_express2),11)
rownames(score_express2)=rownames(final_express2)
colnames(score_express2)=c("ENSG00000265356.1","ENSG00000260719.1","ENSG00000259834.1","ENSG00000264016.2",
"ENSG00000225986.1","ENSG00000231768.1","ENSG00000250073.2",
"os_time","vital_status","risk_score","risk_level")
score_express2[,1]=final_express2[,"ENSG00000253405.1"]
score_express2[,2]=final_express2[,"ENSG00000265356.1"]
score_express2[,3]=final_express2[,"ENSG00000264016.2"]
score_express2[,4]=final_express2[,"ENSG00000260719.1"]
score_express2[,5]=final_express2[,"ENSG00000259834.1"]
score_express2[,6]=final_express2[,"ENSG00000231768.1"]
score_express2[,7]=final_express2[,"ENSG00000240219.1"]
score_express2[,8]=final_express2[,"os_time"]
score_express2[,9]=final_express2[,"vital_status"]
for(i in 1:nrow(score_express2))
{
	score_express2[i,"risk_score"]=(4.23E-04)*score_express2[i,1]+(1.54E-02)*score_express2[i,2]+
	(-9.70E-03)*score_express2[i,3]+(7.51E-03)*score_express2[i,4]+(-1.31E-03)*score_express2[i,5]+
	(6.64E-03)*score_express2[i,6]+(2.03E-03)*score_express2[i,7]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express2))
{
	if(score_express2[i,"risk_score"]<=cutt_off)
	{
		score_express2[i,"risk_level"]=1 
	}
	else
	{
		score_express2[i,"risk_level"]=2
	}
}

#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
risk_dist=matrix(,nrow=nrow(final_express2),ncol=2)
risk_dist[,1]=c(1:nrow(final_express2))
risk_dist[,2]=sort(score_express2[,"risk_score"])
#plot(sort(score_express2[,"risk_score"]),ylab = "Risk score",)

z <- risk_dist[,1]
df <- data.frame(x = risk_dist[,1], y = risk_dist[,2], z = z)
#将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
p1=ggplot(data = df, mapping = aes(x = risk_dist[,1], y = risk_dist[,2], colour = z)) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=206), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=61, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=266, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(p1,filename = "train_risk_score.png",width = 5,height = 2)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_score_express=data.frame(score_express2[order(score_express2[,"risk_score"]),])
order_score_express$vital_status <- factor(order_score_express$vital_status)
p2=ggplot(data = order_score_express, mapping = aes(x = c(1:nrow(order_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=206), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=61, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=266, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.91, .82),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(p2,filename = "train_risk_score_os.png",width = 5,height = 3.5)


p3=ggpubr::ggarrange(p1,p2,labels = c("A", "B"),ncol=1)
ggsave(p3,filename = "train_risk_score_total.png",width = 5,height = 5)









library(survivalROC)
predsurv<- predict(multi_res2)    
nobs <- NROW(final_express2)
cutoff <- 2
marker1=score_express2$risk_score
marker2=sum(score_express2$risk_score)-score_express2$risk_score
marker3=1-score_express2$risk_score/sum(score_express2$risk_score)

rocfit <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff) ## 预测时间截点
								#span = 0.25*nobs^(-0.20))##span,NNE法的namda##span,NNE法的namda
str(rocfit)## list结构


























###############################################单因素COX分析###############################################

train_express=final_express2[1:246,]	#为了保证gender等字段是数字
train_name=row.names(train_express)
test_name=setdiff(row.names(final_express2), train_name)
train_express=as.data.frame(train_express)
test_express=final_express2[test_name,]
test_express=as.data.frame(test_express)

test_express1 <- final_express2[c(1:50,247:279),]
test_express2 <- final_express2[c(51:100,280:312),]
test_express3 <- final_express2[c(101:150,313:345),]
test_express4 <- final_express2[c(151:200,346:378),]
test_express5 <- final_express2[c(201:246,379:411),]
test_express1 <- as.data.frame(test_express1)
test_express2 <- as.data.frame(test_express2)
test_express3 <- as.data.frame(test_express3)
test_express4 <- as.data.frame(test_express4)
test_express5 <- as.data.frame(test_express5)


#table(train_express$age_at_index,train_express$tumor_stage,train_express$vital_status)
#table(final_express3$age_at_index,final_express3$tumor_stage,final_express3$vital_status)	#基本成比例
covariates <- colnames(train_express)
temp1= which(covariates =="os_time")   
temp2= which(covariates =="vital_status")        
covariates = covariates[-temp1]
covariates = covariates[-temp2]
library("survival")
library("survminer")

univ_formulas <- sapply(covariates,function(x) as.formula(paste('Surv(os_time, vital_status)~', x)))
univ_models <- lapply( univ_formulas, function(x){coxph(x, data = train_express)})

	# Extract data 
univ_results <- lapply(univ_models,
						   function(x){ 
							 x <- summary(x)
							 p.value<-signif(x$wald["pvalue"], digits=2)
							 wald.test<-signif(x$wald["test"], digits=2)
							 beta<-signif(x$coef[1], digits=2);#coeficient beta
							 HR <-signif(x$coef[2], digits=2);#exp(beta)
							 HR.confint.lower <- signif(x$conf.int[,"lower .95"], 2)
							 HR.confint.upper <- signif(x$conf.int[,"upper .95"],2)
							 HR <- paste0(HR, " (", 
										  HR.confint.lower, "-", HR.confint.upper, ")")
							 res<-c(beta, HR, wald.test, p.value)
							 names(res)<-c("beta", "HR (95% CI for HR)", "wald.test", 
										   "p.value")
							 return(res)
							 #return(exp(cbind(coef(x),confint(x))))
						   })
	#as.data.frame(univ_results)
res <- t(as.data.frame(univ_results, check.names = FALSE))
res_unicox=res[which(abs(as.numeric(res[,"p.value"]))<0.05),]



#                       beta       HR (95% CI for HR) wald.test p.value  
#ENSG00000214888.2      "0.0093"   "1 (1-1)"          "13"      "3e-04"  
#ENSG00000224968.1      "0.0075"   "1 (1-1)"          "4.3"     "0.038"  
#ENSG00000265356.1      "0.019"    "1 (1-1)"          "11"      "0.0011" 
#ENSG00000264016.2      "-0.0073"  "0.99 (0.99-1)"    "3.9"     "0.047"  

#ENSG00000260719.1      "0.0047"   "1 (1-1)"          "7.7"     "0.0056" 
#ENSG00000250073.2      "0.0013"   "1 (1-1)"          "5.8"     "0.016"  
#ENSG00000231768.1      "0.0066"   "1 (1-1)"          "5.6"     "0.018"  
#ENSG00000235532.1      "0.004"    "1 (1-1)"          "9.8"     "0.0018" 

#ENSG00000236333.3      "0.0024"   "1 (1-1)"          "6.7"     "0.0096" 
#ENSG00000205056.8      "0.0019"   "1 (1-1)"          "5.1"     "0.024"  
#ENSG00000237807.3      "0.00024"  "1 (1-1)"          "4.7"     "0.03"   
#ENSG00000225986.1      "-0.0031"  "1 (0.99-1)"       "4.3"     "0.039" 
 
#ENSG00000240219.1      "0.0018"   "1 (1-1)"          "13"      "0.00039"
#ENSG00000267194.1      "-0.00016" "1 (1-1)"          "5.2"     "0.022"  
#ENSG00000230234.1      "-0.00098" "1 (1-1)"          "4.6"     "0.032"  
#ENSG00000272620.1      "1.2e-05"  "1 (1-1)"          "3.9"     "0.049" 
 
#days_to_death          "0.00066"  "1 (1-1)"          "22"      "2.1e-06"
#age_at_index           "0.027"    "1 (1-1.1)"        "4.5"     "0.034"  
#tumor_stage            "0.73"     "2.1 (1.5-2.8)"    "22"      "3e-06"  
#days_to_last_follow_up "-0.0024"  "1 (1-1)"          "55"      "1.4e-13"

###############################################单因素COX分析###############################################

###############################################lasso回归分析分析###############################################
library(glmnet)
res_lasso=res_unicox
res_lasso=res_lasso[-20,]
res_lasso=res_lasso[-19,]
res_lasso=res_lasso[-18,]
res_lasso=res_lasso[-17,]

lasso_express=train_express[,rownames(res_lasso)]#存放cox单因素分析筛选出来的lncRNA的表达矩阵
lasso_express=as.matrix(lasso_express)

lasso_ts=matrix(,nrow(train_express),2)
rownames(lasso_ts)=rownames(train_express)
colnames(lasso_ts)=c("time","status")
lasso_ts[,1]=train_express[,234]	#存放lasso_express中样本对应的os_time 
lasso_ts[,2]=train_express[,229]	#存放lasso_express中样本对应的vital_status

#lasso_express是样本的表达矩阵	lasso_ts是lasso_express中每个样本对应的生存时间和生存状态
fit = glmnet(lasso_express, lasso_ts, family = "cox")	
fit2 = glmnet(lasso_express, lasso_ts, family = "cox", maxit = 1000)


png("lasso.png",width = 1300, height = 970,res=245)
plot(fit)
dev.off()

png("lasso2.png",width = 1300, height = 970,res=245)
plot(fit,xvar ="lambda") 
dev.off()



cvfit = cv.glmnet(lasso_express, lasso_ts, family = "cox")		#,alpha = 1
cvfit2 = cv.glmnet(lasso_express, lasso_ts, family="cox", maxit = 1000)
png("lasso3.png",width = 1300, height = 970,res=245)
plot(cvfit,xlab ="Log Lambda")
dev.off()

#cvfit$lambda.min为找到的最有意义的点
Coefficients <- coef(fit, s = cvfit$lambda.min)		
Coefficients2 <- coef(cvfit, s = "lambda.min")		
#coef.min = coef(cvfit, s = "lambda.min")
Active.Index <- which(Coefficients != 0)
Active.Coefficients <- Coefficients[Active.Index]
Active.Index
Active.Coefficients
lasso_lnc=row.names(Coefficients)[Active.Index]

#  "ENSG00000214888.2"		2.084777e-03
#  "ENSG00000224968.1"  	1.435562e-03 
#  "ENSG00000265356.1" 		8.236574e-03
#  "ENSG00000264016.2" 		-2.852890e-03
#  "ENSG00000260719.1" 		2.286156e-03
#  "ENSG00000250073.2"  	2.684486e-04 
#  "ENSG00000231768.1"  	2.051750e-03
#  "ENSG00000205056.8" 		3.476038e-04
#  "ENSG00000237807.3" 		3.026891e-05
#  "ENSG00000225986.1"  	-9.536704e-04
#  "ENSG00000240219.1" 		6.410907e-04
#  "ENSG00000267194.1" 		-3.176862e-05


###############################################lasso回归分析分析###############################################


###########################################训练集Cox多因素分析#################################################################
#思路：选和

#将COX单因素筛选得到的lncRNA提取出来
#lasso_lnc
# "ENSG00000214888.2" "ENSG00000224968.1" "ENSG00000265356.1" "ENSG00000264016.2"
# "ENSG00000260719.1" "ENSG00000250073.2" "ENSG00000231768.1" "ENSG00000205056.8"
# "ENSG00000237807.3" "ENSG00000225986.1" "ENSG00000240219.1" "ENSG00000267194.1"


sper_name=c("ENSG00000224220.1","ENSG00000259834.1","ENSG00000253929.1"
,"ENSG00000250742.1","ENSG00000233117.2","ENSG00000271420.1"
,"ENSG00000261625.1","ENSG00000167912.5","ENSG00000253405.1"
)
#sper_name0.9 "ENSG00000259834.1"	"ENSG00000253929.1"	"ENSG00000167912.5"	"ENSG00000253405.1"

multi_cox_name=union(lasso_lnc, sper_name)



multi_res2<- coxph(Surv(os_time, vital_status) ~ENSG00000214888.2+ENSG00000224968.1+ENSG00000265356.1+ENSG00000264016.2
+ENSG00000260719.1+ENSG00000250073.2+ENSG00000231768.1+ENSG00000205056.8
+ENSG00000237807.3+ENSG00000225986.1+ENSG00000240219.1+ENSG00000267194.1
+ENSG00000259834.1+ENSG00000253929.1+ENSG00000167912.5+ENSG00000253405.1
, data = train_express)






#multi_res2
#                        coef  exp(coef)   se(coef)      z       p
ENSG00000265356.1	1.94E-02	1.02E+00	6.84E-03	2.839	0.00453		#multivariate cox
ENSG00000260719.1	6.88E-03	1.01E+00	2.73E-03	2.515	0.01189		#multivariate cox
ENSG00000259834.1	-1.02E-03	9.99E-01	4.42E-04	-2.307	0.02106		#co-expression relationship
ENSG00000264016.2	-9.41E-03	9.91E-01	4.18E-03	-2.249	0.02452		#multivariate cox
ENSG00000225986.1	-3.11E-03	9.97E-01	1.59E-03	-1.96	0.05002		#multivariate cox
ENSG00000231768.1	6.65E-03	1.01E+00	3.53E-03	1.884	0.05958		#multivariate cox
ENSG00000250073.2	1.00E-03	1.00E+00	5.75E-04	1.742	0.08159		#multivariate cox
ENSG00000205056.8	2.07E-03	1.00E+00	1.25E-03	1.659	0.09711
ENSG00000267194.1	-1.12E-04	1.00E+00	7.22E-05	-1.553	0.12049
ENSG00000240219.1	1.47E-03	1.00E+00	1.19E-03	1.242	0.21432
ENSG00000214888.2	3.75E-03	1.00E+00	3.17E-03	1.185	0.23616
ENSG00000253405.1	3.55E-04	1.00E+00	4.81E-04	0.738	0.46074
ENSG00000224968.1	3.06E-03	1.00E+00	4.55E-03	0.674	0.50051
ENSG00000237807.3	1.18E-04	1.00E+00	2.11E-04	0.558	0.57691
ENSG00000167912.5	-1.38E-04	1.00E+00	2.51E-04	-0.552	0.58123
ENSG00000253929.1	-2.23E-05	1.00E+00	1.86E-04	-0.12	0.90455

Likelihood ratio test=52.86  on 16 df, p=7.945e-06
n= 246, number of events= 53 





#多因素分析结果
###########################################训练集Cox多因素分析#################################################################

	
##################################################################绘制森林图##################################################################
#ggforest(multi_res2,data=score_express2,main="Hazard ratio",cpositions=c(0.10,0.22,0.4),fontsize=1.0,refLabel='reference',noDigits=4)
##################################################################绘制森林图##################################################################
	

###########################################计算训练集中每个样本的risk_score和risk_level#################################################################

#multi_res
score_express2=matrix(,nrow(train_express),11)
rownames(score_express2)=rownames(train_express)
colnames(score_express2)=c("ENSG00000265356.1","ENSG00000260719.1","ENSG00000259834.1","ENSG00000264016.2",
"ENSG00000225986.1","ENSG00000231768.1","ENSG00000250073.2",
"os_time","vital_status","risk_score","risk_level")
score_express2[,1]=train_express[,"ENSG00000265356.1"]
score_express2[,2]=train_express[,"ENSG00000260719.1"]
score_express2[,3]=train_express[,"ENSG00000259834.1"]
score_express2[,4]=train_express[,"ENSG00000264016.2"]
score_express2[,5]=train_express[,"ENSG00000225986.1"]
score_express2[,6]=train_express[,"ENSG00000231768.1"]
score_express2[,7]=train_express[,"ENSG00000250073.2"]
score_express2[,8]=train_express[,"os_time"]
score_express2[,9]=train_express[,"vital_status"]
for(i in 1:nrow(score_express2))
{
	score_express2[i,"risk_score"]=(1.94E-02)*score_express2[i,1]+(6.88E-03)*score_express2[i,2]+
	(-1.02E-03)*score_express2[i,3]+(-9.41E-03)*score_express2[i,4]+(-3.11E-03)*score_express2[i,5]+
	(6.65E-03)*score_express2[i,6]+(1.00E-03)*score_express2[i,7]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express2))
{
	if(score_express2[i,"risk_score"]<=cutt_off)
	{
		score_express2[i,"risk_level"]=1 
	}
	else
	{
		score_express2[i,"risk_level"]=2
	}
}

#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
risk_dist=matrix(,nrow=nrow(train_express),ncol=2)
risk_dist[,1]=c(1:nrow(train_express))
risk_dist[,2]=sort(score_express2[,"risk_score"])
#plot(sort(score_express2[,"risk_score"]),ylab = "Risk score",)

z <- risk_dist[,1]
df <- data.frame(x = risk_dist[,1], y = risk_dist[,2], z = z)
#将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
p1=ggplot(data = df, mapping = aes(x = risk_dist[,1], y = risk_dist[,2], colour = z)) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=123), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=61, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=184, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(p1,filename = "train_risk_score.png",width = 5,height = 2)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_score_express=data.frame(score_express2[order(score_express2[,"risk_score"]),])
order_score_express$vital_status <- factor(order_score_express$vital_status)
p2=ggplot(data = order_score_express, mapping = aes(x = c(1:nrow(order_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=123), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=61, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=184, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.91, .82),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(p2,filename = "train_risk_score_os.png",width = 5,height = 3.5)


p3=ggpubr::ggarrange(p1,p2,labels = c("A", "B"),ncol=1)
ggsave(p3,filename = "train_risk_score_total.png",width = 5,height = 5)




###########################################计算训练集中每个样本的risk_score和risk_level#################################################################
###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################
score_express2=as.data.frame(score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express2)
gg=ggsurvplot(fit, data = score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("Low-risk", "High-risk"),
legend = c(0.8, 0.8),
pval = TRUE,
risk.table = TRUE,
risk.table.col = "strata",
lienetype = "strata",
tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 tables.height = 0.2,
#ggtheme = theme_bw() # Change ggplot2 theme
 )

ggsave("train_KM.png", plot = print(gg), width = 5, height = 5, units = "in")

###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################
library(survivalROC)
predsurv<- predict(multi_res2)    
nobs <- NROW(train_express)
cutoff <- 2
marker1=score_express2$risk_score
marker2=sum(score_express2$risk_score)-score_express2$risk_score
marker3=1-score_express2$risk_score/sum(score_express2$risk_score)

rocfit <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff) ## 预测时间截点
								#span = 0.25*nobs^(-0.20))##span,NNE法的namda##span,NNE法的namda
str(rocfit)## list结构
#List of 6
 #$ cut.values  : num [1:270] -Inf 0.011 0.0127 0.0416 0.0468 ...	用于计算TP和FP的marker值
 #$ TP          : num [1:270] 1 0.997 0.993 0.989 0.985 ...
 #$ FP          : num [1:270] 1 0.995 0.992 0.989 0.986 ...
 #$ predict.time: num 3
 #$ Survival    : num 0.298
 #$ AUC         : num 0.515





plot(rocfit$FP, rocfit$TP, 
		type="l",col="red", ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = paste( "FP \n AUC =",round(rocfit$AUC,3)),
        ylab = "TP",main = "Year = 1" )
    abline(0,1,col="gray",lty=2)##线条颜色

#colnames(score_express2)=c("ENSG00000258077.2","ENSG00000253405.1","ENSG00000233117.2","ENSG00000231768.1",
#"ENSG00000245468.3","ENSG00000167912.5","ENSG00000205056.8","os_time","vital_status","risk_score","risk_level")


predsurv<- predict(multi_res)    
nobs <- NROW(train_express)
cutoff <- 3 
rocfit2 <- survivalROC.C(Stime = train_express$os_time,##生存时间
                                status = train_express$vital_status,## 终止事件   
								marker = train_express$tumor_stage, ## marker value 
                                predict.time = cutoff, ## 预测时间截点
								span= 0.25*nobs^(-0.20))
plot(rocfit2$FP, rocfit2$TP, 
		type="l",col="red", ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = paste( "FP \n AUC =",round(rocfit2$AUC,3)),
        ylab = "TP",main = "Year = 1" )
    abline(0,1,col="gray",lty=2)##线条颜色



#ROCR绘制ROC曲线
library(ROCR)
data(ROCR.simple)
df <- data.frame(ROCR.simple)
head(df)
##   predictions labels
## 1   0.6125478      1
## 2   0.3642710      1
## 3   0.4321361      0
## 4   0.1402911      0
## 5   0.3848959      0
## 6   0.2444155      1
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred,"tpr","fpr")
perf
plot(perf,colorize=TRUE)  





###########################################绘制训练集的ROC curve#################################################################


###########################################绘制训练集的ROC curve#################################################################


ENSG00000265356.1	2.05E-02	1.02E+00	6.91E-03	2.971	0.00297
ENSG00000260719.1	7.85E-03	1.01E+00	2.86E-03	2.744	0.00607
ENSG00000264016.2	-1.03E-02	9.90E-01	4.34E-03	-2.37	0.01781
ENSG00000205056.8	3.28E-03	1.00E+00	1.45E-03	2.264	0.02356
ENSG00000261625.1	-3.85E-03	9.96E-01	1.73E-03	-2.223	0.02619
ENSG00000233117.2	6.35E-04	1.00E+00	3.11E-04	2.043	0.04103
ENSG00000259834.1	-1.19E-03	9.99E-01	6.37E-04	-1.87	0.06151
ENSG00000225986.1	-2.76E-03	9.97E-01	1.59E-03	-1.733	0.08307
ENSG00000250073.2	9.66E-04	1.00E+00	5.87E-04	1.646	0.09974
ENSG00000231768.1	6.16E-03	1.01E+00	3.79E-03	1.626	0.10385
ENSG00000267194.1	-1.11E-04	1.00E+00	7.53E-05	-1.48	0.139
ENSG00000214888.2	3.96E-03	1.00E+00	3.18E-03	1.246	0.2128
ENSG00000237807.3	2.34E-04	1.00E+00	2.34E-04	1.001	0.31702
ENSG00000224968.1	3.06E-03	1.00E+00	4.52E-03	0.676	0.49915
ENSG00000253405.1	3.31E-04	1.00E+00	4.94E-04	0.67	0.50259
ENSG00000240219.1	8.55E-04	1.00E+00	1.29E-03	0.663	0.50723
ENSG00000224220.1	1.32E-03	1.00E+00	2.54E-03	0.52	0.60289
ENSG00000167912.5	-1.11E-04	1.00E+00	2.56E-04	-0.432	0.66561
ENSG00000250742.1	1.11E-04	1.00E+00	2.69E-04	0.414	0.67922
ENSG00000271420.1	-1.67E-04	1.00E+00	8.92E-04	-0.187	0.8519
ENSG00000253929.1	2.82E-05	1.00E+00	1.87E-04	0.151	0.88017


###########################################计算测试集1中每个样本的risk_score和risk_level#################################################################

test_score_express2=matrix(,nrow(test_express1),11)
rownames(test_score_express2)=rownames(test_express1)
colnames(test_score_express2)=c("ENSG00000265356.1","ENSG00000260719.1","ENSG00000264016.2","ENSG00000205056.8",
"ENSG00000261625.1","ENSG00000233117.2","ENSG00000259834.1",
"os_time","vital_status","risk_score","risk_level")
test_score_express2[,1]=test_express1[,"ENSG00000265356.1"]
test_score_express2[,2]=test_express1[,"ENSG00000260719.1"]
test_score_express2[,3]=test_express1[,"ENSG00000264016.2"]
test_score_express2[,4]=test_express1[,"ENSG00000205056.8"]
test_score_express2[,5]=test_express1[,"ENSG00000261625.1"]
test_score_express2[,6]=test_express1[,"ENSG00000233117.2"]
test_score_express2[,7]=test_express1[,"ENSG00000259834.1"]
test_score_express2[,8]=test_express1[,"os_time"]
test_score_express2[,9]=test_express1[,"vital_status"]
for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(2.05E-02)*test_score_express2[i,1]+(7.85E-03)*test_score_express2[i,2]+(-1.03E-02)*test_score_express2[i,3]+
	(3.28E-03)*test_score_express2[i,4]+(-3.85E-03)*test_score_express2[i,5]+(6.35E-04)*test_score_express2[i,6]+(-1.19E-03)*test_score_express2[i,7]
	#test_score_express2[i,"risk_score"]=-test_score_express2[i,7]
}



#cutt_off为risk_score的中位数
cutt_off=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off)
	{
		test_score_express2[i,"risk_level"]=1 
	}
	else
	{
		test_score_express2[i,"risk_level"]=2
	}
}

###########################################计算测试集1中每个样本的risk_score和risk_level#################################################################
###########################################计算测试集1中每个样本的risk_level绘制生存曲线,risk_score相关曲线#################################################################

test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
t1_gg=ggsurvplot(fit, data = test_score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("Low-risk", "High-risk"),
legend = c(0.8, 0.8),
pval = TRUE,
risk.table = TRUE,
risk.table.col = "strata",
lienetype = "strata",
tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 tables.height = 0.2,
#ggtheme = theme_bw() # Change ggplot2 theme
 )
 ggsave("test1_KM.png", plot = print(t1_gg), width = 5, height = 5, units = "in")
 
 
 #将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
t1_p1=ggplot(data = test_score_express2, mapping = aes(x = c(1:nrow(test_score_express2)), y = sort(test_score_express2[,"risk_score"]),
colour = c(1:nrow(test_score_express2)))) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=21, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(t1_p1,filename = "test1_risk_score.png",width = 5,height = 2)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(test_score_express2[order(test_score_express2[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
t1_p2=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=21, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.93, .83),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(t1_p2,filename = "test1_risk_score_os.png",width = 5,height = 3.5)


t1_p3=ggpubr::ggarrange(t1_p1,t1_p2,labels = c("A", "B"),ncol=1)
ggsave(t1_p3,filename = "test1_risk_score_total.png",width = 5,height = 5)



###########################################计算测试集1中每个样本的risk_level绘制生存曲线，risk_score相关曲线#################################################################


###########################################计算测试集2中每个样本的risk_score和risk_level#################################################################

test_score_express2=matrix(,nrow(test_express2),11)
rownames(test_score_express2)=rownames(test_express2)
colnames(test_score_express2)=c("ENSG00000265356.1","ENSG00000260719.1","ENSG00000264016.2","ENSG00000205056.8",
"ENSG00000261625.1","ENSG00000233117.2","ENSG00000259834.1",
"os_time","vital_status","risk_score","risk_level")
test_score_express2[,1]=test_express2[,"ENSG00000265356.1"]
test_score_express2[,2]=test_express2[,"ENSG00000260719.1"]
test_score_express2[,3]=test_express2[,"ENSG00000264016.2"]
test_score_express2[,4]=test_express2[,"ENSG00000205056.8"]
test_score_express2[,5]=test_express2[,"ENSG00000261625.1"]
test_score_express2[,6]=test_express2[,"ENSG00000233117.2"]
test_score_express2[,7]=test_express2[,"ENSG00000259834.1"]
test_score_express2[,8]=test_express2[,"os_time"]
test_score_express2[,9]=test_express2[,"vital_status"]
for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(2.05E-02)*test_score_express2[i,1]+(7.85E-03)*test_score_express2[i,2]+(-1.03E-02)*test_score_express2[i,3]+
	(3.28E-03)*test_score_express2[i,4]+(-3.85E-03)*test_score_express2[i,5]+(6.35E-04)*test_score_express2[i,6]+(-1.19E-03)*test_score_express2[i,7]
	#test_score_express2[i,"risk_score"]=test_score_express2[i,7]
}



#cutt_off为risk_score的中位数
cutt_off=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off)
	{
		test_score_express2[i,"risk_level"]=1 
	}
	else
	{
		test_score_express2[i,"risk_level"]=2
	}
}

###########################################计算测试集2中每个样本的risk_score和risk_level#################################################################
###########################################计算测试集2中每个样本的risk_level绘制生存曲线，risk_score相关曲线#################################################################
test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
t2_gg=ggsurvplot(fit, data = test_score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("Low-risk", "High-risk"),
legend = c(0.8, 0.8),
pval = TRUE,
risk.table = TRUE,
risk.table.col = "strata",
lienetype = "strata",
tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 tables.height = 0.2,
#ggtheme = theme_bw() # Change ggplot2 theme
 )
 ggsave("test2_KM.png", plot = print(t2_gg), width = 5, height = 5, units = "in")
 
 
 #将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
t2_p1=ggplot(data = test_score_express2, mapping = aes(x = c(1:nrow(test_score_express2)), y = sort(test_score_express2[,"risk_score"]),
colour = c(1:nrow(test_score_express2)))) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=21, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(t2_p1,filename = "test2_risk_score.png",width = 5,height = 2)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test2_score_express=data.frame(test_score_express2[order(test_score_express2[,"risk_score"]),])
order_test2_score_express$vital_status <- factor(order_test2_score_express$vital_status)
t2_p2=ggplot(data = order_test2_score_express, mapping = aes(x = c(1:nrow(order_test2_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=21, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.91, .83),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(t2_p2,filename = "test2_risk_score_os.png",width = 5,height = 3.5)


t2_p3=ggpubr::ggarrange(t2_p1,t2_p2,labels = c("A", "B"),ncol=1)
ggsave(t2_p3,filename = "test2_risk_score_total.png",width = 5,height = 5)


###########################################计算测试集2中每个样本的risk_level绘制生存曲线，risk_score相关曲线#################################################################




###########################################计算测试集4中每个样本的risk_score和risk_level#################################################################

test_score_express2=matrix(,nrow(test_express4),11)
rownames(test_score_express2)=rownames(test_express4)
colnames(test_score_express2)=c("ENSG00000265356.1","ENSG00000260719.1","ENSG00000264016.2","ENSG00000205056.8",
"ENSG00000261625.1","ENSG00000233117.2","ENSG00000259834.1",
"os_time","vital_status","risk_score","risk_level")
test_score_express2[,1]=test_express4[,"ENSG00000265356.1"]
test_score_express2[,2]=test_express4[,"ENSG00000260719.1"]
test_score_express2[,3]=test_express4[,"ENSG00000264016.2"]
test_score_express2[,4]=test_express4[,"ENSG00000205056.8"]
test_score_express2[,5]=test_express4[,"ENSG00000261625.1"]
test_score_express2[,6]=test_express4[,"ENSG00000233117.2"]
test_score_express2[,7]=test_express4[,"ENSG00000259834.1"]
test_score_express2[,8]=test_express4[,"os_time"]
test_score_express2[,9]=test_express4[,"vital_status"]
for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(2.05E-02)*test_score_express2[i,1]+(7.85E-03)*test_score_express2[i,2]+(-1.03E-02)*test_score_express2[i,3]+
	(3.28E-03)*test_score_express2[i,4]+(-3.85E-03)*test_score_express2[i,5]+(6.35E-04)*test_score_express2[i,6]+(-1.19E-03)*test_score_express2[i,7]
	#test_score_express2[i,"risk_score"]=-test_score_express2[i,7]
}



#cutt_off为risk_score的中位数
cutt_off=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off)
	{
		test_score_express2[i,"risk_level"]=1 
	}
	else
	{
		test_score_express2[i,"risk_level"]=2
	}
}

###########################################计算测试集4中每个样本的risk_score和risk_level#################################################################
###########################################计算测试集4中每个样本的risk_level绘制生存曲线，risk_score相关曲线#################################################################
test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
t4_gg=ggsurvplot(fit, data = test_score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("Low-risk", "High-risk"),
legend = c(0.8, 0.8),
pval = TRUE,
risk.table = TRUE,
risk.table.col = "strata",
lienetype = "strata",
tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 tables.height = 0.2,
#ggtheme = theme_bw() # Change ggplot2 theme
 )
 ggsave("test4_KM.png", plot = print(t4_gg), width = 5, height = 5, units = "in")
 
 
 #将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
t4_p1=ggplot(data = test_score_express2, mapping = aes(x = c(1:nrow(test_score_express2)), y = sort(test_score_express2[,"risk_score"]),
colour = c(1:nrow(test_score_express2)))) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=21, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(t4_p1,filename = "test4_risk_score.png",width = 5,height = 2)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test4_score_express=data.frame(test_score_express2[order(test_score_express2[,"risk_score"]),])
order_test4_score_express$vital_status <- factor(order_test4_score_express$vital_status)
t4_p2=ggplot(data = order_test4_score_express, mapping = aes(x = c(1:nrow(order_test4_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=41.5), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=21, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=62.5, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.91, .83),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(t4_p2,filename = "test4_risk_score_os.png",width = 5,height = 3.5)


t4_p3=ggpubr::ggarrange(t4_p1,t4_p2,labels = c("A", "B"),ncol=1)
ggsave(t4_p3,filename = "test4_risk_score_total.png",width = 5,height = 5)
###########################################计算测试集4中每个样本的risk_level绘制生存曲线，risk_score相关曲线#################################################################




###########################################将多张图整合在一块的函数#################################################################

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
 
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
 
  numPlots = length(plots)
 
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }
 
 if (numPlots==1) {
    print(plots[[1]])
 
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
 
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
 
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}



















