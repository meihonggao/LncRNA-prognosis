#!/usr/bin/perl -w
use strict;
use warnings;
###################################################################################################
#思路：	将colon相关的gene name和delnc中的lncRNA取交集
		#1.ensembl
		#2.cosmic
		#3.计算ensembl和cosmic的overlap,获得cosmic中gene对应的ENSG ID
		#4.计算cosmic和cor的overlap
###################################################################################################

open ENSEMBL,"gencode.v22.mRNA.txt" or die "Can't open ENSEMBL";		
my $count=0;
my @ensembl;
while(<ENSEMBL>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$ensembl[$count][0]=$temp[0];
	$ensembl[$count][1]=$temp[1];
	#print $gencode_cor[$count][0];
	$count=$count+1;
}
close(ENSEMBL);



open COSMIC,"COAD_positive_gene_AGCOH+COSMIC_CGC.txt" or die "Can't open COSMIC";
$count=0;
my @cosmic;
while(<COSMIC>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$cosmic[$count][0]=$temp[0];
	#print "$cosmic[$count]\n";
	$count=$count+1;
	
}
close(COSMIC);




$count=0;
#计算overlap
for my $i (0 .. $#cosmic)
{
	for my $j (0 .. $#ensembl)
	{
		if($cosmic[$i][0] eq $ensembl[$j][0])
		{
			$cosmic[$i][1]=$ensembl[$j][1];
			#print RESULT "$delnc[$j][0]\t$delnc[$j][1]\n";
			print "$count:	$ensembl[$j][0]\t$ensembl[$j][1]\n";
			$count=$count+1;
			last;
		}
	}
}

print "overlap count is: $count\n";



open COR,"cor_gene.txt" or die "Can't open COR";		
$count=0;
my @cor;
while(<COR>)
{
	my @temp=split /\s+/, $_ ;
	
	for my $i (0 .. $#cosmic)
	{
		if($cosmic[$i][1] eq $temp[0])
		{
			print "$cosmic[$i][0]\t$cosmic[$i][1]\n";
			$cor[$count]=$temp[0];
			$count=$count+1;
		}
	}
	
}
close(COR);