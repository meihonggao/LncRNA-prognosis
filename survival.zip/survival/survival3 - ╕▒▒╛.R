###########################################准备矩阵数据#################################################################

setwd("F:\\Deskdop\\LncRNA\\TCGA_download\\colon\\Analysis\\survival");
library(glmnet)
library("survival")
library("survminer")
library(randomForestSRC)
library(survivalROC)
library(ROCR)

final_express <- read.table(file = "coad_diff_lnc_matrix1.5_tumor_clinic2", sep = "\t", header = TRUE, row.names = 1, stringsAsFactors = TRUE);
final_express=t(final_express)	
final_express2=matrix(,nrow(final_express),ncol(final_express)+1)
rownames(final_express2)=rownames(final_express)
colnames(final_express2)=c(colnames(final_express),"os_time")

final_express2[,1:ncol(final_express)]=final_express[,1:ncol(final_express)]
for(i in 1:nrow(final_express))	#compute os_time
{
	if(final_express[i,"vital_status"]==0)	#vital_status is Alive,survival time is equals to days_to_last_follow_up
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_last_follow_up"]
		#final_express$os_time[i]=final_express$days_to_last_follow_up[i]
	}
	else	#状态为Dead,生存时间为days_to_death
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_death"]
	}
}

#将生存时间过小的样本过滤掉
cutoff_time=10
off_sample_name=c()
for(i in 1:nrow(final_express2))
{
	if((final_express2[i,"os_time"]<=cutoff_time)||(final_express2[i,"tumor_stage"]==5))
	{
		off_sample_name=c(off_sample_name,rownames(final_express2)[i])
		#print(rownames(final_express2)[i])
	}
}

final_express2=final_express2[!rownames(final_express2) %in% off_sample_name , ]	#447====》429

final_express2[,"os_time"]=final_express2[,"os_time"]/365#将生存时间转换为年


#final_express3将gender等字段恢复之前的表示
final_express3=as.data.frame(final_express2)
median_age=median(final_express3[,"age_at_index"])
for(i in 1:nrow(final_express3))
{
	
	
	if(final_express3[i,"vital_status"]==0)
	{
		final_express3[i,"vital_status"]="Alive"
	}
	else
	{
		final_express3[i,"vital_status"]="Dead"
	}
	if(final_express3[i,"gender"]==1)
	{
		final_express3[i,"gender"]="male"
	}
	else
	{
		final_express3[i,"gender"]="female"
	}
	if(final_express3[i,"age_at_index"]<median_age)
	{
		final_express3[i,"age_at_index"]="young"
	}
	else
	{
		final_express3[i,"age_at_index"]="old"
	}
	
	if((final_express3[i,"tumor_stage"]==1)||(final_express3[i,"tumor_stage"]==2))
	{
		final_express3[i,"tumor_stage"]="early"
	}
	if((final_express3[i,"tumor_stage"]==3)||(final_express3[i,"tumor_stage"]==4))
	{
		final_express3[i,"tumor_stage"]="late"
	}
	if(final_express3[i,"tumor_stage"]==5)
	{
		final_express3[i,"tumor_stage"]="not_reported"
	}
	
	
}

###############################################单因素COX分析###############################################
#变换样本，使结果尽可能包含和疾病相关的lnc(或换其他的方法)

#####################0表示Alive,1表示dead
#在411个样本中，选取246个为训练集，剩余165个位测试集
unicox_express=final_express2
unicox_express=as.data.frame(unicox_express)
#table(train_express$age_at_index,train_express$tumor_stage,train_express$vital_status)
#table(final_express3$age_at_index,final_express3$tumor_stage,final_express3$vital_status)	#基本成比例
covariates <- colnames(unicox_express)
temp1= which(covariates =="os_time")   
covariates = covariates[-temp1]
temp2= which(covariates =="vital_status")        
covariates = covariates[-temp2]


univ_formulas <- sapply(covariates,function(x) as.formula(paste('Surv(os_time, vital_status)~', x)))
univ_models <- lapply( univ_formulas, function(x){coxph(x, data = unicox_express)})

# Extract data 
univ_results <- lapply(univ_models,
						   function(x){ 
							 x <- summary(x)
							 p.value<-signif(x$wald["pvalue"], digits=2)
							 wald.test<-signif(x$wald["test"], digits=2)
							 beta<-signif(x$coef[1], digits=2);#coeficient beta
							 HR <-signif(x$coef[2], digits=2);#exp(beta)
							 HR.confint.lower <- signif(x$conf.int[,"lower .95"], 2)
							 HR.confint.upper <- signif(x$conf.int[,"upper .95"],2)
							 HR <- paste0(HR, " (", 
										  HR.confint.lower, "-", HR.confint.upper, ")")
							 res<-c(beta, HR, wald.test, p.value)
							 names(res)<-c("beta", "HR (95% CI for HR)", "wald.test", 
										   "p.value")
							 return(res)
							 #return(exp(cbind(coef(x),confint(x))))
						   })
	#as.data.frame(univ_results)
res <- t(as.data.frame(univ_results, check.names = FALSE))
res_unicox=res[which(abs(as.numeric(res[,"p.value"]))<0.05),]
unicox_name<- rownames(res_unicox)

temp3= which(unicox_name=="days_to_last_follow_up")   
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="tumor_stage")        
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="age_at_index")        
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="days_to_death")        
unicox_name = unicox_name[-temp3]	#30

write.table(unicox_name, file ="unicox.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);


#                         beta       HR (95% CI for HR) wald.test p.value  
#[1] ENSG00000214888.2      "0.024"    "1 (1-1)"          "5.3"     "0.021"  
# ENSG00000265356.1      "0.039"    "1 (1-1.1)"        "5"       "0.025"  
# ENSG00000225335.3      "-0.0057"  "0.99 (0.99-1)"    "9"       "0.0027" 
# ENSG00000240498.5      "-0.0014"  "1 (1-1)"          "4.1"     "0.043"  
# ENSG00000264016.2      "-0.028"   "0.97 (0.95-0.99)" "7.2"     "0.0072" 
# ENSG00000271797.1      "-0.03"    "0.97 (0.95-0.99)" "9.7"     "0.0018" 
# ENSG00000268505.1      "-0.012"   "0.99 (0.98-1)"    "6.5"     "0.011"  
# ENSG00000225383.5      "0.0086"   "1 (1-1)"          "5.9"     "0.015"  
# ENSG00000245526.7      "0.023"    "1 (1-1)"          "11"      "0.00079"
# ENSG00000235532.1      "0.011"    "1 (1-1)"          "9.7"     "0.0019" 
# ENSG00000236333.3      "0.0072"   "1 (1-1)"          "5.1"     "0.023"  
# ENSG00000230798.4      "0.013"    "1 (1-1)"          "9.8"     "0.0018" 
# ENSG00000246334.2      "0.0032"   "1 (1-1)"          "3.9"     "0.049"  
# ENSG00000205056.8      "0.0063"   "1 (1-1)"          "7.3"     "0.0067" 
# ENSG00000267480.1      "-0.0049"  "1 (0.99-1)"       "5"       "0.026"  
# ENSG00000268388.4      "-0.00046" "1 (1-1)"          "6.4"     "0.012"  
# ENSG00000254973.1      "0.0033"   "1 (1-1)"          "4.5"     "0.034"  
# ENSG00000275216.1      "0.00021"  "1 (1-1)"          "11"      "0.00089"
# ENSG00000231412.2      "0.001"    "1 (1-1)"          "4"       "0.045"  
# ENSG00000259347.4      "0.0097"   "1 (1-1)"          "8.7"     "0.0032" 
# ENSG00000255571.5      "0.0058"   "1 (1-1)"          "16"      "6.1e-05"
# ENSG00000265485.4      "-0.01"    "0.99 (0.98-1)"    "6.3"     "0.012"  
# ENSG00000260877.1      "0.0021"   "1 (1-1)"          "4.5"     "0.034"  
# ENSG00000218416.4      "0.002"    "1 (1-1)"          "4.7"     "0.031"  
# ENSG00000163009.7      "0.002"    "1 (1-1)"          "11"      "0.00097"
# ENSG00000237070.1      "0.00043"  "1 (1-1)"          "5.2"     "0.023"  
# ENSG00000235884.3      "6e-04"    "1 (1-1)"          "4.8"     "0.028"  
# ENSG00000180869.4      "-0.0034"  "1 (0.99-1)"       "5.2"     "0.023"  
# ENSG00000253405.1      "0.0014"   "1 (1-1)"          "17"      "3.3e-05"
#[30] ENSG00000228437.4      "0.001"    "1 (1-1)"          "19"      "1.4e-05"
# days_to_death          "7e-04"    "1 (1-1)"          "39"      "4.8e-10"
# age_at_index           "0.019"    "1 (1-1)"          "4.2"     "0.041"  
# tumor_stage            "0.83"     "2.3 (1.8-2.9)"    "41"      "1.5e-10"
# days_to_last_follow_up "-0.0026"  "1 (1-1)"          "85"      "3.6e-20"
###############################################单因素COX分析###############################################


###############################################随机生存森林RSF分析###############################################
#RSF_express=as.data.frame(final_express2[,c(1:420,424,429)])	#为了保证gender等字段是数字
#RSF_express=as.data.frame(final_express2[,c(lasso_lnc,"vital_status","os_time")])	#为了保证gender等字段是数字
RSF_express=as.data.frame(final_express2)	#为了保证gender等字段是数字

set.seed(1)
v.obj2 <- rfsrc(Surv(os_time, vital_status) ~ ., data = RSF_express, ntree = 100,block.size = 1)


## print and plot the grow object
print(v.obj2)
plot(v.obj2)

## plot survival curves for first 10 individuals -- direct way
matplot(v.obj2$time.interest, 100 * t(v.obj2$survival.oob[1:10, ]),
    xlab = "Time", ylab = "Survival", type = "l", lty = 1)

## plot survival curves for first 10 individuals
## using function "plot.survival" 
plot.survival(v.obj2, subset = 1:10)


## fast nodesize optimization for RSF_express
## optimal nodesize in survival is larger than other families
## see the function "tune" for more examples
set.seed(1)
tune.nodesize(Surv(os_time,vital_status) ~ ., RSF_express)
set.seed(1)
our.rf=var.select(object=v.obj2,vdv,method="vh.vimp",nrep=100) #迭代100次
#our.rf$topvars
our.rf$varselect
rsf_name<-rownames(subset(our.rf$varselect, our.rf$varselect[,"rel.freq"] >= 9))
temp4= which(rsf_name =="days_to_last_follow_up")        
rsf_name = rsf_name[-temp4]
temp4= which(rsf_name =="days_to_death")        
rsf_name = rsf_name[-temp4]

union(unicox_name,rsf_name)

write.table(rownames(rsf_name), file ="RSF.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);
#write.table(union(unicox_name,rsf_name), file ="t.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);


#######



# "tumor_stage"            "days_to_last_follow_up" "ENSG00000260719.1"      "race"                  
# "ENSG00000205056.8" 

# ENSG00000225335.3       26
# ENSG00000253405.1       26
# ENSG00000228437.4       26
# ENSG00000235532.1       24
# ENSG00000230798.4       24
# ENSG00000268388.4       24
# ENSG00000265485.4       24
# ENSG00000275216.1       22
# ENSG00000264016.2       18
# ENSG00000205056.8       18
# ENSG00000180869.4       18
# ENSG00000259347.4       14
# ENSG00000255026.1       12
# ENSG00000271797.1       10
# ENSG00000268505.1       10
# ENSG00000163009.7       10
# ENSG00000225383.5        8
# ENSG00000265356.1        6
# ENSG00000245526.7        6
# ENSG00000218416.4        6
# ENSG00000222033.1        4
# ENSG00000231412.2        0

#                       rel.freq
# tumor_stage                  21
# ENSG00000228437.4            16
# days_to_death                16
# ENSG00000233554.4            13
# ENSG00000237438.5            13
# ENSG00000230798.4            12
# ENSG00000246334.2            11
# ENSG00000163009.7            11
# days_to_last_follow_up       11
# ENSG00000268388.4            10
# ENSG00000267530.2            10
# ENSG00000259347.4            10
# ENSG00000223573.5             9
# ENSG00000267480.1             9
# ENSG00000265485.4             9
# ENSG00000253405.1             9

###############################################随机生存森林RSF分析###############################################





###############################################单因素COX分析结果和cor0.7结果取并集###############################################
#rownames(res_unicox)[1:30]
#cor_matrix <- read.table(file = "cor_lnc.txt", sep = "\t", row.names = 1, stringsAsFactors = TRUE);
#cor_name=rownames(cor_matrix)	#68
#cor_name=c("ENSG00000237125.7","ENSG00000166770.9","ENSG00000227051.5","ENSG00000234456.6","ENSG00000255248.5")
#union_lnc=union(unicox_name,cor_name)	#93
#write.table(union_lnc, file ="union.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);
###############################################单因素COX分析结果和cor0.7结果取并集###############################################



###############################################lasso回归分析分析###############################################
################lasso回归分析中，1表示死亡，0表示右截尾（Alive）
################lasso回归的前提是变量数(差异lnc)大于样本数,
################lasso回归的目的是将不重要的变量的系数压缩为0
#RSF
rsf_matrix <- read.table(file = "RSF.txt", sep = "\t", row.names = 1, stringsAsFactors = TRUE);
rsf_name=rownames(rsf_matrix)	#13

union(unicox_name,rsf_name)	#34
lasso_express1=final_express2[,union(unicox_name,rsf_name)]#lasso_express是样本的表达矩阵

lasso_ts1=matrix(,nrow(lasso_express1),2)#lasso_ts1是lasso_express中每个样本对应的生存时间和生存状态
rownames(lasso_ts1)=rownames(lasso_express1)
colnames(lasso_ts1)=c("time","status")
lasso_ts1[,1]=as.double(final_express2[,"os_time"])	#存放lasso_express中样本对应的os_time 
lasso_ts1[,2]=as.double(final_express2[,"vital_status"])	#存放lasso_express中样本对应的vital_status
#y <- data.matrix(Surv(final_express2[,"os_time"],final_express2[,"vital_status"]))


lasso_express1=as.matrix(lasso_express1)
set.seed(15)
fit1 = glmnet(lasso_express1, lasso_ts1, family = "cox")	#alpha=1 is the lasso penalty, and alpha=0 the ridge penalty
#print(fit1)
#plot(fit1)

png("lasso.png",width = 1300, height = 1200,res=245)
plot(fit1)
dev.off()

png("lasso2.png",width = 1300, height = 1200,res=245)
plot(fit1,xvar ="lambda") 
dev.off()


#head(coef(fit1, s=c(fit1$lambda[29],0.009)))
#plot.glmnet(model_lasso, xvar = "norm", label = TRUE)
#plot(model_lasso, xvar="lambda", label=TRUE)



set.seed(15)
cvfit1 = cv.glmnet(lasso_express1, lasso_ts1, family = "cox")		#两条虚线分别指示了两个特殊的λ值,一个是lambda.min,一个是lambda.1se,这两个值之间的lambda都认为是合适的。lambda.1se构建的模型最简单，即使用的基因数量少，而lambda.min则准确率更高一点，使用的基因数量更多一点
#plot(cvfit1)

png("lasso3.png",width = 1300, height = 1200,res=245)
plot(cvfit1,xlab ="Log Lambda")
dev.off()

#cvfit1$lambda.min为找到的最有意义的点,用得到的最有意义的点去建模，lASSO可以防止过度拟合
#model_lasso_min <- glmnet(lasso_express1, lasso_ts1, alpha = 1, lambda=cvfit1$lambda.min)
#model_lasso_1se <- glmnet(x=x, y=y, alpha = 1, lambda=cv_fit1$lambda.1se)


Coefficients <- coef(fit1, s = cvfit1$lambda.min)		
Coefficients2 <- coef(cvfit1, s = "lambda.min")		
#coef.min = coef(cvfit2, s = "lambda.min")
Active.Index <- which(Coefficients != 0)
Active.Coefficients <- Coefficients[Active.Index]
Active.Index
Active.Coefficients
lasso_lnc=row.names(Coefficients)[Active.Index]

Active.Index2 <- which(Coefficients2 != 0)
Active.Coefficients2 <- Coefficients2[Active.Index]
Active.Index2
Active.Coefficients2
lasso_lnc2=row.names(Coefficients2)[Active.Index2]		#20

write.table(lasso_lnc, file ="lasso.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);#将lasso_lnc输出

#lasso_lnc分别和unicox和cor取交集	rownames(cor_matrix)
#intersect(lasso_lnc,rownames(res_unicox)[1:30])		#20
#intersect(lasso_lnc,rownames(cor_matrix))			#5
#intersect(rownames(res_unicox)[1:30],rownames(cor_matrix))	#5
#union(rownames(res_unicox)[1:30],rownames(cor_matrix))
###############################################lasso回归分析分析###############################################





###########################################训练集Cox多因素分析#################################################################

#unicox:30
#cor:68
#lasso:22
#RSF:13

cor_name=c("ENSG00000237125.7","ENSG00000166770.9","ENSG00000227051.5","ENSG00000234456.6","ENSG00000255248.5")
union_lnc=union(lasso_lnc,cor_name)
#筛选进行多因素cox分析的lncRNA特征
for(i in 1:length(union_lnc))	#对每个单因素lasso筛选出的lncRNA的表达量和生存时间的KM分析
{
	lasso_exp=matrix(,nrow(final_express2),4)
	rownames(lasso_exp)=rownames(final_express2)
	colnames(lasso_exp)=c(union_lnc[i],"os_time","vital_status","exp_level")
	lasso_exp=as.data.frame(lasso_exp)
	lasso_exp[,1:3]=final_express2[,c(union_lnc[i],"os_time","vital_status")]
	
	cutt_off=median(lasso_exp[,union_lnc[i]])	#cutt_off为表达值的中位数
	
	for(j in 1:nrow(lasso_exp)) #根据cutt_off计算risk_level,0代表低表达，1代表高表达
	{
		if(lasso_exp[j,1]<=cutt_off)
		{
			lasso_exp[j,"exp_level"]=0 
		}
		else
		{
			lasso_exp[j,"exp_level"]=1
		}
	}
	
	fit<- survfit(Surv(os_time, vital_status) ~ exp_level, data = lasso_exp)#根据每个lnc的exp_level绘制KM生存曲线
	ggsurvplot(fit, data = lasso_exp,
	surv.median.line = "hv", # Add medians survival
	legend.title = "risk level",
	legend.labs = c("low", "high"),
	pval = TRUE,
	risk.table = TRUE,
	#tables.height = 0.2,
	#tables.theme = theme_cleantable(),
	palette = c("#0000FF", "#FF0000"),
	#ggtheme = theme_bw() # Change ggplot2 theme
	)
}

#
#> union(lasso_lnc,cor_name)
# [1] "ENSG00000225335.3" "ENSG00000264016.2" "ENSG00000271797.1"
 #[4] "ENSG00000245526.7" "ENSG00000235532.1" "ENSG00000230798.4"
# [7] "ENSG00000268388.4" "ENSG00000275216.1" "ENSG00000259347.4"
#[10] "ENSG00000265485.4" "ENSG00000218416.4" "ENSG00000163009.7"
#[13] "ENSG00000253405.1" "ENSG00000228437.4" "ENSG00000237125.7"
#[16] "ENSG00000166770.9" "ENSG00000227051.5" "ENSG00000234456.6"
#[19] "ENSG00000255248.5"

multi_res1<-coxph(Surv(os_time, vital_status) ~ENSG00000225335.3+ENSG00000264016.2+ENSG00000271797.1+
ENSG00000245526.7+ENSG00000235532.1+ENSG00000230798.4+
ENSG00000268388.4+ENSG00000275216.1+ENSG00000259347.4+
ENSG00000265485.4+ENSG00000218416.4+ENSG00000163009.7+
ENSG00000253405.1+ENSG00000228437.4+ENSG00000237125.7+
ENSG00000166770.9+ENSG00000227051.5+ENSG00000234456.6+
ENSG00000255248.5
, data = as.data.frame(final_express2[1:287,]))

#	coef	exp(coef)	se(coef)	z	p
#ENSG00000259347.4	1.23E-02	1.01E+00	3.88E-03	3.159	0.00158
#ENSG00000228437.4	1.15E-03	1.00E+00	3.66E-04	3.145	0.00166
#ENSG00000253405.1	1.83E-03	1.00E+00	6.26E-04	2.92	0.0035
#ENSG00000271797.1	-3.31E-02	9.67E-01	1.52E-02	-2.18	0.02929
#ENSG00000264016.2	-3.10E-02	9.70E-01	1.51E-02	-2.045	0.04083
#ENSG00000166770.9	5.79E-03	1.01E+00	3.03E-03	1.914	0.05563
#ENSG00000268388.4	-4.88E-04	1.00E+00	2.98E-04	-1.638	0.10138
#ENSG00000237125.7	-3.53E-03	9.96E-01	2.26E-03	-1.557	0.11938
#ENSG00000275216.1	1.53E-04	1.00E+00	1.08E-04	1.427	0.15352
#ENSG00000234456.6	-0.0012004	0.9988003	0.0008652	-1.387	0.16529
#ENSG00000255248.5	0.0009335	1.0009339	0.0007833	1.192	0.23341
#ENSG00000245526.7	1.19E-02	1.01E+00	1.03E-02	1.154	0.24833
#ENSG00000163009.7	9.86E-04	1.00E+00	9.14E-04	1.079	0.28053
#ENSG00000230798.4	8.38E-03	1.01E+00	8.19E-03	1.024	0.30598
#ENSG00000225335.3	-2.74E-03	9.97E-01	2.80E-03	-0.977	0.32859
#ENSG00000235532.1	6.93E-03	1.01E+00	7.67E-03	0.904	0.36609
#ENSG00000227051.5	3.94E-04	1.00E+00	7.17E-04	0.55	0.58229
#ENSG00000265485.4	-2.24E-03	9.98E-01	5.62E-03	-0.398	0.69057
#ENSG00000218416.4	-4.33E-04	1.00E+00	2.46E-03	-0.176	0.86056

#Likelihood	ratio	test=65.91	on	19	df,	p=4.338e-07
#n=	287,	number	of	events=	57	



multi_res2<-coxph(Surv(os_time, vital_status) ~ENSG00000225335.3+ENSG00000264016.2+ENSG00000271797.1+
ENSG00000245526.7+ENSG00000235532.1+ENSG00000230798.4+
ENSG00000268388.4+ENSG00000275216.1+ENSG00000259347.4+
ENSG00000265485.4+
#ENSG00000218416.4+
ENSG00000163009.7+
ENSG00000253405.1+ENSG00000228437.4+ENSG00000237125.7+
ENSG00000166770.9+
ENSG00000227051.5+
ENSG00000234456.6+
ENSG00000255248.5
, data = as.data.frame(final_express2[1:287,]))

#ENSG00000228437.4	0.0011532	1.0011539	0.0003638	3.17	0.00152
#ENSG00000259347.4	1.23E-02	1.01E+00	3.88E-03	3.167	0.00154
#ENSG00000253405.1	1.84E-03	1.00E+00	6.24E-04	2.946	0.00322
#ENSG00000271797.1	-3.31E-02	9.67E-01	1.52E-02	-2.182	0.02913
#ENSG00000264016.2	-3.09E-02	9.70E-01	1.51E-02	-2.044	0.041
#ENSG00000166770.9	5.76E-03	1.01E+00	3.02E-03	1.908	0.05639
#ENSG00000268388.4	-4.98E-04	1.00E+00	2.94E-04	-1.696	0.08992
#ENSG00000237125.7	-3.47E-03	9.97E-01	2.23E-03	-1.556	0.11974
#ENSG00000275216.1	1.50E-04	1.00E+00	1.06E-04	1.415	0.15699
#ENSG00000234456.6	-1.20E-03	9.99E-01	8.67E-04	-1.38	0.16753
#ENSG00000255248.5	0.0009527	1.0009532	0.0007759	1.228	0.21948
#ENSG00000245526.7	1.19E-02	1.01E+00	1.04E-02	1.147	0.25124
#ENSG00000163009.7	1.00E-03	1.00E+00	9.07E-04	1.106	0.26873
#ENSG00000230798.4	8.36E-03	1.01E+00	8.20E-03	1.019	0.30797
#ENSG00000225335.3	-2.77E-03	9.97E-01	2.80E-03	-0.986	0.32391
#ENSG00000235532.1	7.07E-03	1.01E+00	7.64E-03	0.924	0.35532
#ENSG00000227051.5	3.74E-04	1.00E+00	7.11E-04	0.526	0.59917
#ENSG00000265485.4	-2.09E-03	9.98E-01	5.55E-03	-0.377	0.70598



multi_res3<-coxph(Surv(os_time, vital_status) ~ENSG00000225335.3+ENSG00000264016.2+ENSG00000271797.1+
ENSG00000245526.7+ENSG00000235532.1+ENSG00000230798.4+
ENSG00000268388.4+ENSG00000275216.1+ENSG00000259347.4+
#ENSG00000265485.4+
#ENSG00000218416.4+
ENSG00000163009.7+
ENSG00000253405.1+ENSG00000228437.4+ENSG00000237125.7+
ENSG00000166770.9+
ENSG00000227051.5+
ENSG00000234456.6+
ENSG00000255248.5
, data = as.data.frame(final_express2[1:287,]))

#ENSG00000259347.4	0.0125002	1.0125786	0.0038199	3.272	0.00107
#ENSG00000228437.4	0.0011273	1.001128	0.0003613	3.12	0.00181
#ENSG00000253405.1	0.0018224	1.0018241	0.0006259	2.911	0.0036
#ENSG00000271797.1	-0.0342537	0.9663264	0.0149289	-2.294	0.02176
#ENSG00000264016.2	-0.0310417	0.9694351	0.0151263	-2.052	0.04015
#ENSG00000166770.9	0.0058602	1.0058774	0.0030046	1.95	0.05113
#ENSG00000268388.4	-0.0005378	0.9994624	0.0002771	-1.941	0.05225
#ENSG00000275216.1	0.0001594	1.0001594	0.0001031	1.547	0.12188
#ENSG00000237125.7	-0.0034097	0.9965961	0.0022134	-1.54	0.12345
#ENSG00000234456.6	-0.0011971	0.9988036	0.0008666	-1.381	0.16714
#ENSG00000255248.5	0.0009777	1.0009782	0.0007731	1.265	0.20597
#ENSG00000163009.7	0.0010475	1.0010481	0.0008972	1.168	0.24296
#ENSG00000245526.7	0.0117003	1.011769	0.0103111	1.135	0.25649
#ENSG00000230798.4	0.008943	1.0089831	0.0080273	1.114	0.26525
#ENSG00000225335.3	-0.0028543	0.9971497	0.0028016	-1.019	0.30828
#ENSG00000235532.1	0.0071774	1.0072033	0.007628	0.941	0.34674
#ENSG00000227051.5	0.0003619	1.000362	0.0007092	0.51	0.60978

Likelihood ratio test=65.73  on 17 df, p=1.155e-07
n= 287, number of events= 57 



multi_res4<-coxph(Surv(os_time, vital_status) ~ENSG00000225335.3+ENSG00000264016.2+ENSG00000271797.1+
ENSG00000245526.7+ENSG00000235532.1+ENSG00000230798.4+
ENSG00000268388.4+ENSG00000275216.1+ENSG00000259347.4+
#ENSG00000265485.4+
#ENSG00000218416.4+
ENSG00000163009.7+
ENSG00000253405.1+ENSG00000228437.4+ENSG00000237125.7+
ENSG00000166770.9+
#ENSG00000227051.5+
ENSG00000234456.6+
ENSG00000255248.5
, data = as.data.frame(final_express2[1:287,]))


#ENSG00000259347.4	0.0126948	1.0127757	0.0037992	3.341	0.000833
#ENSG00000228437.4	0.0011064	1.001107	0.0003634	3.045	0.002331
#ENSG00000253405.1	0.0018182	1.0018198	0.0006254	2.907	0.003647
#ENSG00000271797.1	-0.0342018	0.9663765	0.014929	-2.291	0.021966
#ENSG00000166770.9	0.0061149	1.0061336	0.0029303	2.087	0.03691
#ENSG00000264016.2	-0.0299009	0.9705417	0.0149522	-2	0.045526

#ENSG00000268388.4	-0.0005164	0.9994837	0.0002731	-1.891	0.058592
#ENSG00000275216.1	0.0001652	1.0001652	0.0001028	1.606	0.108231
#ENSG00000237125.7	-0.0030188	0.9969857	0.0020785	-1.452	0.146391
#ENSG00000255248.5	0.001018	1.0010186	0.0007597	1.34	0.180209
#ENSG00000235532.1	0.0089273	1.0089672	0.0067199	1.328	0.184018
#ENSG00000234456.6	-0.0010256	0.9989749	0.0007871	-1.303	0.192589
#ENSG00000245526.7	0.0125272	1.012606	0.0100487	1.247	0.212527
#ENSG00000163009.7	0.0010459	1.0010465	0.0008932	1.171	0.241634
#ENSG00000225335.3	-0.0030587	0.996946	0.0027658	-1.106	0.268763
#ENSG00000230798.4	0.0087125	1.0087506	0.0080563	1.081	0.279491

#Likelihood ratio test=65.49  on 16 df, p=6.065e-08
#n= 287, number of events= 57 



###########################################训练集Cox多因素分析#################################################################

	

###########################################计算训练集中每个样本的risk_score和risk_level#################################################################
#multi_res
train_express=final_express2[1:287,]
score_express2=matrix(,nrow(train_express),10)
rownames(score_express2)=rownames(train_express)
colnames(score_express2)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")
score_express2[,1:8]=train_express[,colnames(score_express2)[1:8]]

for(i in 1:nrow(score_express2))
{
	score_express2[i,"risk_score"]=(0.0126948)*score_express2[i,1]+(0.0011064)*score_express2[i,2]+(0.0018182)*score_express2[i,3]+
	(-0.0342018)*score_express2[i,4]+(0.0061149)*score_express2[i,5]+(-0.0299009)*score_express2[i,6]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express2))
{
	if(score_express2[i,"risk_score"]<=cutt_off)
	{
		score_express2[i,"risk_level"]=0 
	}
	else
	{
		score_express2[i,"risk_level"]=1
	}
}

#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
risk_dist=matrix(,nrow=nrow(train_express),ncol=2)
risk_dist[,1]=c(1:nrow(train_express))
risk_dist[,2]=sort(score_express2[,"risk_score"])
#plot(sort(score_express2[,"risk_score"]),ylab = "Risk score",)

z <- risk_dist[,1]
df <- data.frame(x = risk_dist[,1], y = risk_dist[,2], z = z)
#将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
p1=ggplot(data = df, mapping = aes(x = risk_dist[,1], y = risk_dist[,2], colour = z)) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("Patients (increasing risk score)") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=144), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=61, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=205, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(p1,filename = "train_risk_score.png",width = 5,height = 3.27)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_score_express=data.frame(score_express2[order(score_express2[,"risk_score"]),])
order_score_express$vital_status <- factor(order_score_express$vital_status)
p2=ggplot(data = order_score_express, mapping = aes(x = c(1:nrow(order_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=144), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=61, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=205, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.91, .82),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(p2,filename = "train_risk_score_os.png",width = 5,height = 3.5)


p3=ggpubr::ggarrange(p1,p2,labels = c("A", "B"),ncol=1)
ggsave(p3,filename = "train_risk_score_total.png",width = 5,height = 5)

###########################################计算训练集中每个样本的risk_score和risk_level#################################################################

###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################
score_express2=as.data.frame(score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express2)
gg=ggsurvplot(fit, data = score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
#surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("low", "high"),
legend = c(0.8, 0.8),	#改变图例位置
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("train_KM.png", plot = print(gg), width = 5, height = 5, units = "in")
###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################

#predsurv<- predict(multi_res2)    
nobs <- NROW(train_express)
cutoff1 <- 1
cutoff2 <- 2
cutoff3 <- 3
cutoff4 <- 4
cutoff5 <- 5
cutoff6 <- 6
marker1=score_express2$risk_score
marker2=sum(score_express2$risk_score)-score_express2$risk_score
marker3=1-score_express2$risk_score/sum(score_express2$risk_score)

rocfit1 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff1) ## 预测时间截点

rocfit2 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff2) ## 预测时间截点

rocfit3 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff3) ## 预测时间截点

rocfit4 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff4) ## 预测时间截点

rocfit5 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff5) ## 预测时间截点

rocfit6 <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff6) ## 预测时间截点


train_roc_data=data.frame(rocfit1$FP,rocfit1$TP,rocfit2$FP,rocfit2$TP,
rocfit3$FP,rocfit3$TP,rocfit4$FP,rocfit4$TP,rocfit5$FP,rocfit5$TP,rocfit6$FP,rocfit6$TP)

gg_train_roc=ggplot()+labs(x = "False positive rate", y = "Ture positive rate", title ="ROC curve (training set)")+
		geom_line(data = train_roc_data,aes(x = rocfit1.FP,y = rocfit1.TP,colour = "pink"),size=1)+
		 geom_line(data = train_roc_data,aes(x = rocfit2.FP,y = rocfit2.TP,colour ="blue"),size=1) + 
         geom_line(data = train_roc_data,aes(x = rocfit3.FP,y = rocfit3.TP,colour ="green"),size=1) + 
		 geom_line(data = train_roc_data,aes(x = rocfit4.FP,y = rocfit4.TP,colour ="black"),size=1) + 
		 geom_line(data = train_roc_data,aes(x = rocfit5.FP,y = rocfit5.TP,colour ="yellow"),size=1) + 
		 geom_line(data = train_roc_data,aes(x = rocfit6.FP,y = rocfit6.TP,colour ="purple"),size=1) + 
		 theme_bw()+
		 scale_color_manual(values=c("pink","blue","green","black","yellow","purple"),
		 labels = c(paste("year=1, AUC=",round(rocfit1$AUC,4)), 
		 paste("year=2, AUC=",round(rocfit2$AUC,4)),
		 paste("year=3, AUC=",round(rocfit3$AUC,4)),
		 paste("year=4, AUC=",round(rocfit4$AUC,4)),
		 paste("year=5, AUC=",round(rocfit5$AUC,4)),
		 paste("year=6, AUC=",round(rocfit6$AUC,4))))+	#对默认给定的颜色进行修改
		 theme(panel.grid =element_blank(),	#去除网格
		 plot.title = element_text(hjust = 0.5),#标题居中
		 #legend.position="none",	# 移除所有图例
		 legend.position=c(.72, .42),
		legend.title=element_blank(),
			axis.text.x = element_text(size = 15, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
			axis.text.y = element_text(size = 15, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
			axis.title.x = element_text(size = 15, color = "black"),
			axis.title.y = element_text(size = 15, color = "black"))
ggsave(gg_train_roc,filename = "train_roc.png",width = 5,height = 3.5)		 
		 
		 
		 
if(1>0)
{
plot(rocfit1$FP, rocfit1$TP, 
		type="l",col=c(1), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate",main = "RPC curve (train set)" )
    abline(0,1,col="gray",lty=2)##线条颜色
lines(rocfit2$FP, rocfit2$TP, 
		type="l",col=c(2), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate")
lines(rocfit3$FP, rocfit3$TP, 
		type="l",col=c(3), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate")
lines(rocfit4$FP, rocfit4$TP, 
		type="l",col=c(4), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate")
lines(rocfit5$FP, rocfit5$TP, 
		type="l",col=c(5), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate")
lines(rocfit6$FP, rocfit6$TP, 
		type="l",col=c(6), ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = "False positive rate",
        ylab = "True positive rate")
legend("bottomright",pch=c(15,15),legend=c(paste("year=1, AUC=",round(rocfit1$AUC,5)),
paste("year=2, AUC=",round(rocfit2$AUC,5)),
paste("year=3, AUC=",round(rocfit3$AUC,5)),
paste("year=4, AUC=",round(rocfit4$AUC,5)),
paste("year=5, AUC=",round(rocfit5$AUC,5)),
paste("year=6, AUC=",round(rocfit6$AUC,5))),
col=c(1,2,3,4,5,6),bty="n")
}





#ROCR绘制ROC曲线

data(ROCR.simple)
df <- data.frame(ROCR.simple)
head(df)
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred,"tpr","fpr")
perf
plot(perf,colorize=TRUE)  
###########################################计算训练集中每个样本的risk_score和risk_level#################################################################


###########################################计算测试集中每个样本的risk_score和risk_level#################################################################
test_express=final_express2[288:411,]
test_score_express2=matrix(,nrow(test_express),10)
rownames(test_score_express2)=rownames(test_express)
colnames(test_score_express2)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")

test_score_express2[,1:8]=test_express[,colnames(test_score_express2)[1:8]]

for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(0.0126948)*test_score_express2[i,1]+(0.0011064)*test_score_express2[i,2]+(0.0018182)*test_score_express2[i,3]+
	(-0.0342018)*test_score_express2[i,4]+(0.0061149)*test_score_express2[i,5]+(-0.0299009)*test_score_express2[i,6]
}

#cutt_off为risk_score的中位数
cutt_off=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off)
	{
		test_score_express2[i,"risk_level"]=0 
	}
	else
	{
		test_score_express2[i,"risk_level"]=1
	}
}




###########################################计算测试集中每个样本的risk_score和risk_level#################################################################
###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################
test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
t_gg=ggsurvplot(fit, data = test_score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
#surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("low", "high"),
legend = c(0.8, 0.8),	#改变图例位置
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("test_KM.png", plot = print(t_gg), width = 5, height = 5, units = "in")



#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
library(ggplot2)
t_p1=ggplot(data = test_score_express2, mapping = aes(x = c(1:nrow(test_score_express2)), y = sort(test_score_express2[,"risk_score"]),
colour = c(1:nrow(test_score_express2)))) + 
geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
xlab("Patients (increasing risk score)") + 
theme(axis.title.x = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
ylab("Risk score") + 
theme(axis.title.y = element_text(size = 30, color = "black", face = "bold", vjust = 0.5, hjust = 0.5))+
theme_bw()+
geom_vline(aes(xintercept=62), colour="#009600", linetype="dashed",size=1)+
theme(panel.grid =element_blank())+		#删除网格
annotate("text", x=21, y=1, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=83, y=1, label="High risk",alpha=.5,colour="darkred")+ 
theme(legend.position="none")
ggsave(t_p1,filename = "test_risk_score.png",width = 5,height = 3.27)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(test_score_express2[order(test_score_express2[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
t_p2=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
colour = vital_status)) + 
scale_color_manual(values=c(4.8,2),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
geom_point(size = 1.5)+
labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
theme_bw()+
theme(panel.grid =element_blank())+		#删除网格
geom_vline(aes(xintercept=62), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
annotate("text", x=21, y=10, label="Low risk",alpha=.5,colour="darkblue")+ 
annotate("text", x=83, y=10, label="High risk",alpha=.5,colour="darkred")+
theme(legend.position=c(.93, .83),legend.key=element_rect(fill="white",color="black",size=0.5),
legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'))
ggsave(t_p2,filename = "test_risk_score_os.png",width = 5,height = 3.5)


t_p3=ggpubr::ggarrange(t_p1,t_p2,labels = c("A", "B"),ncol=1)
ggsave(t_p3,filename = "test_risk_score_total.png",width = 5,height = 5)
###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################


###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################
    
nobs <- NROW(test_express)
cutoff1 <- 1
cutoff2 <- 2
cutoff3 <- 3
cutoff4 <- 4
cutoff5 <- 5
cutoff6 <- 6
marker1=test_score_express2$risk_score
marker2=sum(test_score_express2$risk_score)-test_score_express2$risk_score
marker3=1-test_score_express2$risk_score/sum(test_score_express2$risk_score)
rocfit1 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff1) ## 预测时间截点

rocfit2 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff2) ## 预测时间截点

rocfit3 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff3) ## 预测时间截点

rocfit4 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff4) ## 预测时间截点

rocfit5 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff5) ## 预测时间截点

rocfit6 <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff6) ## 预测时间截点
#str(rocfit)## list结构

test_roc_data=data.frame(rocfit1$FP,rocfit1$TP,rocfit2$FP,rocfit2$TP,
rocfit3$FP,rocfit3$TP,rocfit4$FP,rocfit4$TP,rocfit5$FP,rocfit5$TP,rocfit6$FP,rocfit6$TP)

gg_test_roc=ggplot()+labs(x = "False positive rate", y = "Ture positive rate", title ="ROC curve (training set)")+
		geom_line(data = test_roc_data,aes(x = rocfit1.FP,y = rocfit1.TP,colour = "pink"),size=1)+
		 geom_line(data = test_roc_data,aes(x = rocfit2.FP,y = rocfit2.TP,colour ="blue"),size=1) + 
         geom_line(data = test_roc_data,aes(x = rocfit3.FP,y = rocfit3.TP,colour ="green"),size=1) + 
		 geom_line(data = test_roc_data,aes(x = rocfit4.FP,y = rocfit4.TP,colour ="black"),size=1) + 
		 geom_line(data = test_roc_data,aes(x = rocfit5.FP,y = rocfit5.TP,colour ="yellow"),size=1) + 
		 geom_line(data = test_roc_data,aes(x = rocfit6.FP,y = rocfit6.TP,colour ="purple"),size=1) + 
		 theme_bw()+
		 scale_color_manual(values=c("pink","blue","green","black","yellow","purple"),
		 labels = c(paste("year=1, AUC=",round(rocfit1$AUC,4)), 
		 paste("year=2, AUC=",round(rocfit2$AUC,4)),
		 paste("year=3, AUC=",round(rocfit3$AUC,4)),
		 paste("year=4, AUC=",round(rocfit4$AUC,4)),
		 paste("year=5, AUC=",round(rocfit5$AUC,4)),
		 paste("year=6, AUC=",round(rocfit6$AUC,4))))+	#对默认给定的颜色进行修改
		 theme(panel.grid =element_blank(),	#去除网格
		 plot.title = element_text(hjust = 0.5),#标题居中
		 #legend.position="none",	# 移除所有图例
		 legend.position=c(.72, .42),
		legend.title=element_blank(),
			axis.text.x = element_text(size = 15, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
			axis.text.y = element_text(size = 15, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
			axis.title.x = element_text(size = 15, color = "black"),
			axis.title.y = element_text(size = 15, color = "black"))
ggsave(gg_test_roc,filename = "test_roc.png",width = 5,height = 3.5)		




















#ROCR绘制ROC曲线

data(ROCR.simple)
df <- data.frame(ROCR.simple)
head(df)
##   predictions labels
## 1   0.6125478      1
## 2   0.3642710      1
## 3   0.4321361      0
## 4   0.1402911      0
## 5   0.3848959      0
## 6   0.2444155      1
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred,"tpr","fpr")
perf
plot(perf,colorize=TRUE)  
###########################################计算测试集中每个样本的risk_score和risk_level#################################################################



