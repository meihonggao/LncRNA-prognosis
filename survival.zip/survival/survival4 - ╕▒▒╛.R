###########################################准备矩阵数据#################################################################

setwd("F:\\Deskdop\\LncRNA\\TCGA_download\\colon\\Analysis\\survival");
library(glmnet)
library("survival")
library("survminer")
library(randomForestSRC)
library(survivalROC)
library(ROCR)

final_express <- read.table(file = "coad_diff_lnc_matrix1.5_tumor_clinic2", sep = "\t", header = TRUE, row.names = 1, stringsAsFactors = TRUE);
final_express=t(final_express)	
final_express2=matrix(,nrow(final_express),ncol(final_express)+1)
rownames(final_express2)=rownames(final_express)
colnames(final_express2)=c(colnames(final_express),"os_time")

final_express2[,1:ncol(final_express)]=final_express[,1:ncol(final_express)]
for(i in 1:nrow(final_express))	#compute os_time
{
	if(final_express[i,"vital_status"]==0)	#vital_status is Alive,survival time is equals to days_to_last_follow_up
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_last_follow_up"]
		#final_express$os_time[i]=final_express$days_to_last_follow_up[i]
	}
	else	#状态为Dead,生存时间为days_to_death
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_death"]
	}
}

#将生存时间过小的样本过滤掉
cutoff_time=10
off_sample_name=c()
for(i in 1:nrow(final_express2))
{
	if((final_express2[i,"os_time"]<=cutoff_time)||(final_express2[i,"tumor_stage"]==5))
	{
		off_sample_name=c(off_sample_name,rownames(final_express2)[i])
		#print(rownames(final_express2)[i])
	}
}

final_express2=final_express2[!rownames(final_express2) %in% off_sample_name , ]	#447====》429

final_express2[,"os_time"]=final_express2[,"os_time"]/365#将生存时间转换为年


#final_express3将gender等字段恢复之前的表示
final_express3=as.data.frame(final_express2)
median_age=median(final_express3[,"age_at_index"])
for(i in 1:nrow(final_express3))
{
	
	
	if(final_express3[i,"vital_status"]==0)
	{
		final_express3[i,"vital_status"]="Alive"
	}
	else
	{
		final_express3[i,"vital_status"]="Dead"
	}
	if(final_express3[i,"gender"]==1)
	{
		final_express3[i,"gender"]="male"
	}
	else
	{
		final_express3[i,"gender"]="female"
	}
	if(final_express3[i,"age_at_index"]<median_age)
	{
		final_express3[i,"age_at_index"]="young"
	}
	else
	{
		final_express3[i,"age_at_index"]="old"
	}
	
	if((final_express3[i,"tumor_stage"]==1)||(final_express3[i,"tumor_stage"]==2))
	{
		final_express3[i,"tumor_stage"]="early"
	}
	if((final_express3[i,"tumor_stage"]==3)||(final_express3[i,"tumor_stage"]==4))
	{
		final_express3[i,"tumor_stage"]="late"
	}
	if(final_express3[i,"tumor_stage"]==5)
	{
		final_express3[i,"tumor_stage"]="not_reported"
	}
	
	
}

###############################################单因素COX分析###############################################
#变换样本，使结果尽可能包含和疾病相关的lnc(或换其他的方法)

#####################0表示Alive,1表示dead
#在411个样本中，选取246个为训练集，剩余165个位测试集
unicox_express=final_express2
unicox_express=as.data.frame(unicox_express)
#table(train_express$age_at_index,train_express$tumor_stage,train_express$vital_status)
#table(final_express3$age_at_index,final_express3$tumor_stage,final_express3$vital_status)	#基本成比例
covariates <- colnames(unicox_express)
temp1= which(covariates =="os_time")   
covariates = covariates[-temp1]
temp2= which(covariates =="vital_status")        
covariates = covariates[-temp2]


univ_formulas <- sapply(covariates,function(x) as.formula(paste('Surv(os_time, vital_status)~', x)))
univ_models <- lapply( univ_formulas, function(x){coxph(x, data = unicox_express)})

# Extract data 
univ_results <- lapply(univ_models,
						   function(x){ 
							 x <- summary(x)
							 p.value<-signif(x$wald["pvalue"], digits=2)
							 wald.test<-signif(x$wald["test"], digits=2)
							 beta<-signif(x$coef[1], digits=2);#coeficient beta
							 HR <-signif(x$coef[2], digits=2);#exp(beta)
							 HR.confint.lower <- signif(x$conf.int[,"lower .95"], 2)
							 HR.confint.upper <- signif(x$conf.int[,"upper .95"],2)
							 HR <- paste0(HR, " (", 
										  HR.confint.lower, "-", HR.confint.upper, ")")
							 res<-c(beta, HR, wald.test, p.value)
							 names(res)<-c("beta", "HR (95% CI for HR)", "wald.test", 
										   "p.value")
							 return(res)
							 #return(exp(cbind(coef(x),confint(x))))
						   })
	#as.data.frame(univ_results)
res <- t(as.data.frame(univ_results, check.names = FALSE))
res_unicox=res[which(abs(as.numeric(res[,"p.value"]))<0.05),]
unicox_name<- rownames(res_unicox)

temp3= which(unicox_name=="days_to_last_follow_up")   
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="tumor_stage")        
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="age_at_index")        
unicox_name = unicox_name[-temp3]
temp3= which(unicox_name=="days_to_death")        
unicox_name = unicox_name[-temp3]	#30

write.table(unicox_name, file ="unicox.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);


#                         beta       HR (95% CI for HR) wald.test p.value  
#[1] ENSG00000214888.2      "0.024"    "1 (1-1)"          "5.3"     "0.021"  
# ENSG00000265356.1      "0.039"    "1 (1-1.1)"        "5"       "0.025"  
# ENSG00000225335.3      "-0.0057"  "0.99 (0.99-1)"    "9"       "0.0027" 
# ENSG00000240498.5      "-0.0014"  "1 (1-1)"          "4.1"     "0.043"  
# ENSG00000264016.2      "-0.028"   "0.97 (0.95-0.99)" "7.2"     "0.0072" 
# ENSG00000271797.1      "-0.03"    "0.97 (0.95-0.99)" "9.7"     "0.0018" 
# ENSG00000268505.1      "-0.012"   "0.99 (0.98-1)"    "6.5"     "0.011"  
# ENSG00000225383.5      "0.0086"   "1 (1-1)"          "5.9"     "0.015"  
# ENSG00000245526.7      "0.023"    "1 (1-1)"          "11"      "0.00079"
# ENSG00000235532.1      "0.011"    "1 (1-1)"          "9.7"     "0.0019" 
# ENSG00000236333.3      "0.0072"   "1 (1-1)"          "5.1"     "0.023"  
# ENSG00000230798.4      "0.013"    "1 (1-1)"          "9.8"     "0.0018" 
# ENSG00000246334.2      "0.0032"   "1 (1-1)"          "3.9"     "0.049"  
# ENSG00000205056.8      "0.0063"   "1 (1-1)"          "7.3"     "0.0067" 
# ENSG00000267480.1      "-0.0049"  "1 (0.99-1)"       "5"       "0.026"  
# ENSG00000268388.4      "-0.00046" "1 (1-1)"          "6.4"     "0.012"  
# ENSG00000254973.1      "0.0033"   "1 (1-1)"          "4.5"     "0.034"  
# ENSG00000275216.1      "0.00021"  "1 (1-1)"          "11"      "0.00089"
# ENSG00000231412.2      "0.001"    "1 (1-1)"          "4"       "0.045"  
# ENSG00000259347.4      "0.0097"   "1 (1-1)"          "8.7"     "0.0032" 
# ENSG00000255571.5      "0.0058"   "1 (1-1)"          "16"      "6.1e-05"
# ENSG00000265485.4      "-0.01"    "0.99 (0.98-1)"    "6.3"     "0.012"  
# ENSG00000260877.1      "0.0021"   "1 (1-1)"          "4.5"     "0.034"  
# ENSG00000218416.4      "0.002"    "1 (1-1)"          "4.7"     "0.031"  
# ENSG00000163009.7      "0.002"    "1 (1-1)"          "11"      "0.00097"
# ENSG00000237070.1      "0.00043"  "1 (1-1)"          "5.2"     "0.023"  
# ENSG00000235884.3      "6e-04"    "1 (1-1)"          "4.8"     "0.028"  
# ENSG00000180869.4      "-0.0034"  "1 (0.99-1)"       "5.2"     "0.023"  
# ENSG00000253405.1      "0.0014"   "1 (1-1)"          "17"      "3.3e-05"
#[30] ENSG00000228437.4      "0.001"    "1 (1-1)"          "19"      "1.4e-05"
# days_to_death          "7e-04"    "1 (1-1)"          "39"      "4.8e-10"
# age_at_index           "0.019"    "1 (1-1)"          "4.2"     "0.041"  
# tumor_stage            "0.83"     "2.3 (1.8-2.9)"    "41"      "1.5e-10"
# days_to_last_follow_up "-0.0026"  "1 (1-1)"          "85"      "3.6e-20"
###############################################单因素COX分析###############################################


###############################################随机生存森林RSF分析###############################################
#RSF_express=as.data.frame(final_express2[,c(1:420,424,429)])	#为了保证gender等字段是数字
#RSF_express=as.data.frame(final_express2[,c(lasso_lnc,"vital_status","os_time")])	#为了保证gender等字段是数字
RSF_express=as.data.frame(final_express2)	#为了保证gender等字段是数字

set.seed(1)
v.obj2 <- rfsrc(Surv(os_time, vital_status) ~ ., data = RSF_express, ntree = 100,block.size = 1)


## print and plot the grow object
print(v.obj2)
plot(v.obj2)

## plot survival curves for first 10 individuals -- direct way
matplot(v.obj2$time.interest, 100 * t(v.obj2$survival.oob[1:10, ]),
    xlab = "Time", ylab = "Survival", type = "l", lty = 1)

## plot survival curves for first 10 individuals
## using function "plot.survival" 
plot.survival(v.obj2, subset = 1:10)


## fast nodesize optimization for RSF_express
## optimal nodesize in survival is larger than other families
## see the function "tune" for more examples
set.seed(1)
tune.nodesize(Surv(os_time,vital_status) ~ ., RSF_express)
set.seed(1)
our.rf=var.select(object=v.obj2,vdv,method="vh.vimp",nrep=100) #迭代100次
#our.rf$topvars
our.rf$varselect
rsf_name<-rownames(subset(our.rf$varselect, our.rf$varselect[,"rel.freq"] >= 9))
temp4= which(rsf_name =="days_to_last_follow_up")        
rsf_name = rsf_name[-temp4]
temp4= which(rsf_name =="days_to_death")        
rsf_name = rsf_name[-temp4]

union(unicox_name,rsf_name)

write.table(rownames(rsf_name), file ="RSF.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);
#write.table(union(unicox_name,rsf_name), file ="t.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);


#######



# "tumor_stage"            "days_to_last_follow_up" "ENSG00000260719.1"      "race"                  
# "ENSG00000205056.8" 

# ENSG00000225335.3       26
# ENSG00000253405.1       26
# ENSG00000228437.4       26
# ENSG00000235532.1       24
# ENSG00000230798.4       24
# ENSG00000268388.4       24
# ENSG00000265485.4       24
# ENSG00000275216.1       22
# ENSG00000264016.2       18
# ENSG00000205056.8       18
# ENSG00000180869.4       18
# ENSG00000259347.4       14
# ENSG00000255026.1       12
# ENSG00000271797.1       10
# ENSG00000268505.1       10
# ENSG00000163009.7       10
# ENSG00000225383.5        8
# ENSG00000265356.1        6
# ENSG00000245526.7        6
# ENSG00000218416.4        6
# ENSG00000222033.1        4
# ENSG00000231412.2        0

#                       rel.freq
# tumor_stage                  21
# ENSG00000228437.4            16
# days_to_death                16
# ENSG00000233554.4            13
# ENSG00000237438.5            13
# ENSG00000230798.4            12
# ENSG00000246334.2            11
# ENSG00000163009.7            11
# days_to_last_follow_up       11
# ENSG00000268388.4            10
# ENSG00000267530.2            10
# ENSG00000259347.4            10
# ENSG00000223573.5             9
# ENSG00000267480.1             9
# ENSG00000265485.4             9
# ENSG00000253405.1             9

###############################################随机生存森林RSF分析###############################################





###############################################单因素COX分析结果和cor0.7结果取并集###############################################
#rownames(res_unicox)[1:30]
#cor_matrix <- read.table(file = "cor_lnc.txt", sep = "\t", row.names = 1, stringsAsFactors = TRUE);
#cor_name=rownames(cor_matrix)	#68
#cor_name=c("ENSG00000237125.7","ENSG00000166770.9","ENSG00000227051.5","ENSG00000234456.6","ENSG00000255248.5")
#union_lnc=union(unicox_name,cor_name)	#93
#write.table(union_lnc, file ="union.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);
###############################################单因素COX分析结果和cor0.7结果取并集###############################################



###############################################lasso回归分析分析###############################################
################lasso回归分析中，1表示死亡，0表示右截尾（Alive）
################lasso回归的前提是变量数(差异lnc)大于样本数,
################lasso回归的目的是将不重要的变量的系数压缩为0
#RSF
rsf_matrix <- read.table(file = "RSF.txt", sep = "\t", row.names = 1, stringsAsFactors = TRUE);
rsf_name=rownames(rsf_matrix)	#13

union(unicox_name,rsf_name)	#34
lasso_express1=final_express2[,union(unicox_name,rsf_name)]#lasso_express是样本的表达矩阵

lasso_ts1=matrix(,nrow(lasso_express1),2)#lasso_ts1是lasso_express中每个样本对应的生存时间和生存状态
rownames(lasso_ts1)=rownames(lasso_express1)
colnames(lasso_ts1)=c("time","status")
lasso_ts1[,1]=as.double(final_express2[,"os_time"])	#存放lasso_express中样本对应的os_time 
lasso_ts1[,2]=as.double(final_express2[,"vital_status"])	#存放lasso_express中样本对应的vital_status
#y <- data.matrix(Surv(final_express2[,"os_time"],final_express2[,"vital_status"]))


lasso_express1=as.matrix(lasso_express1)
set.seed(28)
fit1 = glmnet(lasso_express1, lasso_ts1, family = "cox")	#alpha=1 is the lasso penalty, and alpha=0 the ridge penalty
print(fit1)
plot(fit1)
#head(coef(fit1, s=c(fit1$lambda[29],0.009)))
#plot.glmnet(model_lasso, xvar = "norm", label = TRUE)
#plot(model_lasso, xvar="lambda", label=TRUE)



set.seed(28)
cvfit1 = cv.glmnet(lasso_express1, lasso_ts1, family = "cox")		#两条虚线分别指示了两个特殊的λ值,一个是lambda.min,一个是lambda.1se,这两个值之间的lambda都认为是合适的。lambda.1se构建的模型最简单，即使用的基因数量少，而lambda.min则准确率更高一点，使用的基因数量更多一点
plot(cvfit1)



#cvfit1$lambda.min为找到的最有意义的点,用得到的最有意义的点去建模，lASSO可以防止过度拟合
#model_lasso_min <- glmnet(lasso_express1, lasso_ts1, alpha = 1, lambda=cvfit1$lambda.min)
#model_lasso_1se <- glmnet(x=x, y=y, alpha = 1, lambda=cv_fit1$lambda.1se)


Coefficients <- coef(fit1, s = cvfit1$lambda.min)		
Coefficients2 <- coef(cvfit1, s = "lambda.min")		
#coef.min = coef(cvfit2, s = "lambda.min")
Active.Index <- which(Coefficients != 0)
Active.Coefficients <- Coefficients[Active.Index]
Active.Index
Active.Coefficients
lasso_lnc=row.names(Coefficients)[Active.Index]

Active.Index2 <- which(Coefficients2 != 0)
Active.Coefficients2 <- Coefficients2[Active.Index]
Active.Index2
Active.Coefficients2
lasso_lnc2=row.names(Coefficients2)[Active.Index2]		#20

write.table(lasso_lnc, file ="lasso.txt",sep="\t",row.names =FALSE, col.names =FALSE, quote =TRUE);#将lasso_lnc输出

#lasso_lnc分别和unicox和cor取交集	rownames(cor_matrix)
#intersect(lasso_lnc,rownames(res_unicox)[1:30])		#20
#intersect(lasso_lnc,rownames(cor_matrix))			#5
#intersect(rownames(res_unicox)[1:30],rownames(cor_matrix))	#5
#union(rownames(res_unicox)[1:30],rownames(cor_matrix))
###############################################lasso回归分析分析###############################################





###########################################训练集Cox多因素分析#################################################################

#unicox:30
#cor:68
#lasso:22
#RSF:13

cor_name=c("ENSG00000237125.7","ENSG00000166770.9","ENSG00000227051.5","ENSG00000234456.6","ENSG00000255248.5")
union_lnc=union(lasso_lnc,cor_name)
#筛选进行多因素cox分析的lncRNA特征
for(i in 1:length(union_lnc))	#对每个单因素lasso筛选出的lncRNA的表达量和生存时间的KM分析
{
	lasso_exp=matrix(,nrow(final_express2),4)
	rownames(lasso_exp)=rownames(final_express2)
	colnames(lasso_exp)=c(union_lnc[i],"os_time","vital_status","exp_level")
	lasso_exp=as.data.frame(lasso_exp)
	lasso_exp[,1:3]=final_express2[,c(union_lnc[i],"os_time","vital_status")]
	
	cutt_off=median(lasso_exp[,union_lnc[i]])	#cutt_off为表达值的中位数
	
	for(j in 1:nrow(lasso_exp)) #根据cutt_off计算risk_level,0代表低表达，1代表高表达
	{
		if(lasso_exp[j,1]<=cutt_off)
		{
			lasso_exp[j,"exp_level"]=0 
		}
		else
		{
			lasso_exp[j,"exp_level"]=1
		}
	}
	
	fit<- survfit(Surv(os_time, vital_status) ~ exp_level, data = lasso_exp)#根据每个lnc的exp_level绘制KM生存曲线
	ggsurvplot(fit, data = lasso_exp,
	surv.median.line = "hv", # Add medians survival
	legend.title = "risk level",
	legend.labs = c("low", "high"),
	pval = TRUE,
	risk.table = TRUE,
	#tables.height = 0.2,
	#tables.theme = theme_cleantable(),
	palette = c("#0000FF", "#FF0000"),
	#ggtheme = theme_bw() # Change ggplot2 theme
	)
}


# union(lasso_lnc,cor_name)
# [1] "ENSG00000264016.2" "ENSG00000271797.1" "ENSG00000230798.4"
# [4] "ENSG00000275216.1" "ENSG00000259347.4" "ENSG00000163009.7"
# [7] "ENSG00000253405.1" "ENSG00000228437.4" "ENSG00000237125.7"
#[10] "ENSG00000166770.9" "ENSG00000227051.5" "ENSG00000234456.6"
#[13] "ENSG00000255248.5"
multi_res<-coxph(Surv(os_time, vital_status) ~ENSG00000264016.2+ENSG00000271797.1+ENSG00000230798.4+
ENSG00000275216.1+ENSG00000259347.4+ENSG00000163009.7+
ENSG00000253405.1+ENSG00000228437.4+ENSG00000237125.7+
ENSG00000166770.9+ENSG00000227051.5+ENSG00000234456.6+
ENSG00000255248.5
, data = as.data.frame(final_express2[1:247,]))

#					coef		exp(coef)	se(coef)	z		p
#ENSG00000228437.4	1.36E-03	1.00E+00	3.33E-04	4.079	4.51E-05
#ENSG00000259347.4	1.23E-02	1.01E+00	3.60E-03	3.419	0.000629
#ENSG00000271797.1	-4.48E-02	9.56E-01	1.44E-02	-3.123	0.001789
#ENSG00000264016.2	-4.17E-02	9.59E-01	1.53E-02	-2.735	0.006236

#ENSG00000230798.4	1.66E-02	1.02E+00	6.19E-03	2.679	0.007375
#ENSG00000253405.1	1.48E-03	1.00E+00	5.58E-04	2.658	0.007855
#ENSG00000237125.7	-4.76E-03	9.95E-01	2.08E-03	-2.289	0.022078

#ENSG00000275216.1	1.49E-04	1.00E+00	9.91E-05	1.504	0.13249
#ENSG00000227051.5	7.60E-04	1.00E+00	5.46E-04	1.393	0.163676
#ENSG00000163009.7	1.19E-03	1.00E+00	9.00E-04	1.317	0.187698
#ENSG00000255248.5	9.26E-04	1.00E+00	7.35E-04	1.259	0.208059
#ENSG00000166770.9	3.45E-03	1.00E+00	2.77E-03	1.248	0.212122
#ENSG00000234456.6	-7.08E-04	9.99E-01	7.94E-04	-0.893	0.372004


#Likelihood	ratio	test=56.44	on	13	df,	p=2.251e-07
#n=	287,	number	of	events=	57	


###########################################训练集Cox多因素分析#################################################################

###########################################计算训练集中每个样本的risk_score和risk_level#################################################################
#multi_res
train_express=final_express2[1:247,]
score_express2=matrix(,nrow(train_express),11)
rownames(score_express2)=rownames(train_express)
colnames(score_express2)=c("ENSG00000228437.4","ENSG00000259347.4","ENSG00000271797.1","ENSG00000264016.2",
"ENSG00000230798.4","ENSG00000253405.1","ENSG00000237125.7",
"os_time","vital_status","risk_score","risk_level")
score_express2[,1]=train_express[,"ENSG00000228437.4"]
score_express2[,2]=train_express[,"ENSG00000259347.4"]
score_express2[,3]=train_express[,"ENSG00000271797.1"]
score_express2[,4]=train_express[,"ENSG00000264016.2"]
score_express2[,5]=train_express[,"ENSG00000230798.4"]
score_express2[,6]=train_express[,"ENSG00000253405.1"]
score_express2[,7]=train_express[,"ENSG00000237125.7"]
score_express2[,8]=train_express[,"os_time"]
score_express2[,9]=train_express[,"vital_status"]
for(i in 1:nrow(score_express2))
{
	score_express2[i,"risk_score"]=(2.22E-03)*score_express2[i,1]+(1.02E-02)*score_express2[i,2]+
	(-4.48E-02)*score_express2[i,3]+(-4.17E-02)*score_express2[i,4]+(1.66E-02)*score_express2[i,5]+
	(1.48E-03)*score_express2[i,6]+(-4.76E-03)*score_express2[i,7]
}

#cutt_off为risk_score的中位数
cutt_off=median(score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express2))
{
	if(score_express2[i,"risk_score"]<=cutt_off)
	{
		score_express2[i,"risk_level"]=0 
	}
	else
	{
		score_express2[i,"risk_level"]=1
	}
}

###########################################计算训练集中每个样本的risk_score和risk_level#################################################################

###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################
score_express2=as.data.frame(score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express2)
ggsurvplot(fit, data = score_express2,
surv.median.line = "hv", # Add medians survival
legend.title = "risk level",
legend.labs = c("low", "high"),
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )

###########################################计算训练集中每个样本的risk_level绘制生存曲线#################################################################

predsurv<- predict(multi_res2)    
nobs <- NROW(train_express)
cutoff <- 4
marker1=score_express2$risk_score
marker2=sum(score_express2$risk_score)-score_express2$risk_score
marker3=1-score_express2$risk_score/sum(score_express2$risk_score)

rocfit <- survivalROC.C(Stime = score_express2$os_time,##生存时间
                                status = score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff) ## 预测时间截点
								#span = 0.25*nobs^(-0.20))##span,NNE法的namda##span,NNE法的namda
str(rocfit)## list结构


   
nobs <- NROW(train_express)
cutoff <- 3 
rocfit2 <- survivalROC.C(Stime = train_express$os_time,##生存时间
                                status = train_express$vital_status,## 终止事件   
								marker = train_express$tumor_stage, ## marker value 
                                predict.time = cutoff, ## 预测时间截点
								span= 0.25*nobs^(-0.20))
plot(rocfit$FP, rocfit$TP, 
		type="l",col="red", ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = paste( "FP \n AUC =",round(rocfit$AUC,3)),
        ylab = "TP",main = "Year = 1" )
    abline(0,1,col="gray",lty=2)##线条颜色



#ROCR绘制ROC曲线

data(ROCR.simple)
df <- data.frame(ROCR.simple)
head(df)
##   predictions labels
## 1   0.6125478      1
## 2   0.3642710      1
## 3   0.4321361      0
## 4   0.1402911      0
## 5   0.3848959      0
## 6   0.2444155      1
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred,"tpr","fpr")
perf
plot(perf,colorize=TRUE)  
###########################################计算训练集中每个样本的risk_score和risk_level#################################################################


###########################################计算测试集中每个样本的risk_score和risk_level#################################################################
#test_express=final_express2[288:411,]
test_express=final_express2[248:411,]
test_score_express2=matrix(,nrow(test_express),11)
rownames(test_score_express2)=rownames(test_express)

colnames(test_score_express2)=c("ENSG00000228437.4","ENSG00000259347.4","ENSG00000271797.1","ENSG00000264016.2",
"ENSG00000230798.4","ENSG00000253405.1","ENSG00000237125.7",
"os_time","vital_status","risk_score","risk_level")
test_score_express2[,1]=test_express[,"ENSG00000228437.4"]
test_score_express2[,2]=test_express[,"ENSG00000259347.4"]
test_score_express2[,3]=test_express[,"ENSG00000271797.1"]
test_score_express2[,4]=test_express[,"ENSG00000264016.2"]
test_score_express2[,5]=test_express[,"ENSG00000230798.4"]
test_score_express2[,6]=test_express[,"ENSG00000253405.1"]
test_score_express2[,7]=test_express[,"ENSG00000237125.7"]
test_score_express2[,8]=test_express[,"os_time"]
test_score_express2[,9]=test_express[,"vital_status"]
for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(2.22E-03)*test_score_express2[i,1]+(1.02E-02)*test_score_express2[i,2]+
	(-4.48E-02)*test_score_express2[i,3]+(-4.17E-02)*test_score_express2[i,4]+(1.66E-02)*test_score_express2[i,5]+
	(1.48E-03)*test_score_express2[i,6]+(-4.76E-03)*test_score_express2[i,7]
}



#cutt_off为risk_score的中位数
cutt_off=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off)
	{
		test_score_express2[i,"risk_level"]=0 
	}
	else
	{
		test_score_express2[i,"risk_level"]=1
	}
}

###########################################计算测试集中每个样本的risk_score和risk_level#################################################################
###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################
test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
ggsurvplot(fit, data = test_score_express2,
surv.median.line = "hv", # Add medians survival
legend.title = "risk level",
legend.labs = c("low", "high"),
pval = TRUE,
risk.table = TRUE,
#tables.height = 0.2,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )

###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################


###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################
    
nobs <- NROW(test_express)
cutoff <- 4
marker1=test_score_express2$risk_score
marker2=sum(test_score_express2$risk_score)-test_score_express2$risk_score
marker3=1-test_score_express2$risk_score/sum(test_score_express2$risk_score)

rocfit <- survivalROC.C(Stime = test_score_express2$os_time,##生存时间
                                status = test_score_express2$vital_status,## 终止事件   
								marker = marker1, ## marker value 
                                predict.time = cutoff) ## 预测时间截点
								#span = 0.25*nobs^(-0.20))##span,NNE法的namda##span,NNE法的namda
str(rocfit)## list结构


   
nobs <- NROW(test_express)
cutoff <- 5
rocfit2 <- survivalROC.C(Stime = test_express$os_time,##生存时间
                                status = test_express$vital_status,## 终止事件   
								marker = test_express$tumor_stage, ## marker value 
                                predict.time = cutoff, ## 预测时间截点
								span= 0.25*nobs^(-0.20))
plot(rocfit$FP, rocfit$TP, 
		type="l",col="red", ##线条设置
        xlim = c(0,1), ylim = c(0,1),
        xlab = paste( "FP \n AUC =",round(rocfit$AUC,3)),
        ylab = "TP",main = "Year = 1" )
    abline(0,1,col="gray",lty=2)##线条颜色



#ROCR绘制ROC曲线

data(ROCR.simple)
df <- data.frame(ROCR.simple)
head(df)
##   predictions labels
## 1   0.6125478      1
## 2   0.3642710      1
## 3   0.4321361      0
## 4   0.1402911      0
## 5   0.3848959      0
## 6   0.2444155      1
pred <- prediction(df$predictions, df$labels)
perf <- performance(pred,"tpr","fpr")
perf
plot(perf,colorize=TRUE)  
###########################################计算测试集中每个样本的risk_score和risk_level#################################################################



