#!/usr/bin/perl -w
use strict;
use warnings;
###################################################################################################
#思路：	将colon相关的gene name和gencode中的lncRNA取交集
		#1.读取colon数据
		#2.读取gencode数据
		#3.取overlap
###################################################################################################

open COLON,"colon.txt" or die "Can't open COLON";
	
	
my $count=0;
my @colon_cor;
while(<COLON>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$colon_cor[$count][0]=$temp[0];
	#print $colon_cor[$count][0];

	$count=$count+1;
	#print "\n";
}
close(COLON);


open GENCODE,"gencode.txt" or die "Can't open GENCODE";
$count=0;
my @gencode;
while(<GENCODE>)
{
	#print "count:$count\n";
	my @temp=split /\s+/, $_ ;
	$gencode[$count][0]=$temp[0];
	$gencode[$count][1]=$temp[1];
	#print "$gencode[$count][0]\t$gencode[$count][1]\n";
	$count=$count+1;
	#print "$gencode[$count][0]\t$gencode[$count][1]\n";
	
}
close(GENCODE);

open RESULT,">overlap.txt"	or die "Can't open RESULT";	
print RESULT "ID\tname\n";
my @overlap_gene;
$count=0;
#计算overlap
for my $i (0 .. $#colon_cor)
{
	
	for my $j (0 .. $#gencode)
	{
		if($colon_cor[$i][0] eq $gencode[$j][1])
		{
			#print RESULT "$gencode[$j][0]\t$gencode[$j][1]\n";
			print "$gencode[$j][0]\t$gencode[$j][1]\n";
			$count=$count+1;
			last;
		}
	}
}

print "overlap count is: $count\n";
close(RESULT);
