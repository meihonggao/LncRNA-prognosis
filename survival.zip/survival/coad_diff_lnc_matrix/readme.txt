Clinical information

gender: 
		male <--> 1		female <--> 2
		
race:	
		white <--> 1	asian <--> 2	black or african american <--> 3	american indian or alaska native <--> 4	not reported <--> 5

ethnicity:	
		hispanic or latino <--> 1	not hispanic or latino <--> 2		not reported <--> 3

vital_status:	
		Alive <--> 0	Dead <--> 1

days_to_death:	
		--  <-->  0

age_at_index: 
		not change

tumor_stage	stage:
		i <--> 1	ii <--> 2	iii <--> 3	iv <-->4	not reported <--> 5

days_to_last_follow_up:	
		--  <-->  0
		
T-stage
Tis-5

M-stage
MX <--> 2		-- <--> 3

treatment_type
Pharmaceutical Therapy, NOS <--> 1		Radiation Therapy, NOS <--> 2


	
	






