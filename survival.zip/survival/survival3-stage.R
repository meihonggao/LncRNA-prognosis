#R 4.0.2版
###########################################准备矩阵数据#################################################################

setwd("E:\\Deskdop\\LncRNA\\TCGA_download\\colon\\Analysis\\survival");
library(glmnet)
library(survival)
library(survminer)
library(randomForestSRC)
library(survivalROC)
library(ROCR)

final_express <- read.table(file = "coad_diff_lnc_matrix1.5_tumor_clinic4", sep = "\t", header = TRUE, row.names = 1, stringsAsFactors = TRUE);
final_express=t(final_express)	
final_express2=matrix(,nrow(final_express),ncol(final_express)+1)
rownames(final_express2)=rownames(final_express)
colnames(final_express2)=c(colnames(final_express),"os_time")

final_express2[,1:ncol(final_express)]=final_express[,1:ncol(final_express)]
for(i in 1:nrow(final_express))	#compute os_time
{
	if(final_express[i,"vital_status"]==0)	#vital_status is Alive,survival time is equals to days_to_last_follow_up
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_last_follow_up"]
		#final_express$os_time[i]=final_express$days_to_last_follow_up[i]
	}
	else	#状态为Dead,生存时间为days_to_death
	{
		final_express2[i,"os_time"]=final_express[i,"days_to_death"]
	}
}

#将生存时间过小的样本过滤掉
cutoff_time=10
off_sample_name=c()
for(i in 1:nrow(final_express2))
{
	if((final_express2[i,"os_time"]<=cutoff_time)||(final_express2[i,"tumor_stage"]==5))
	{
		off_sample_name=c(off_sample_name,rownames(final_express2)[i])
		#print(rownames(final_express2)[i])
	}
}

final_express2=final_express2[!rownames(final_express2) %in% off_sample_name , ]	#447====》429

final_express2[,"os_time"]=final_express2[,"os_time"]/365#将生存时间转换为年


#final_express3将gender等字段恢复之前的表示
final_express3=as.data.frame(final_express2)
median_age=median(final_express3[,"age_at_index"])
for(i in 1:nrow(final_express3))
{
	
	
	if(final_express3[i,"vital_status"]==0)
	{
		final_express3[i,"vital_status"]="Alive"
	}
	else
	{
		final_express3[i,"vital_status"]="Dead"
	}
	if(final_express3[i,"gender"]==1)
	{
		final_express3[i,"gender"]="male"
	}
	else
	{
		final_express3[i,"gender"]="female"
	}
	if(final_express3[i,"age_at_index"]<median_age)
	{
		final_express3[i,"age_at_index"]="young"
	}
	else
	{
		final_express3[i,"age_at_index"]="old"
	}
	
	if((final_express3[i,"tumor_stage"]==1)||(final_express3[i,"tumor_stage"]==2))
	{
		final_express3[i,"tumor_stage"]="early"
	}
	if((final_express3[i,"tumor_stage"]==3)||(final_express3[i,"tumor_stage"]==4))
	{
		final_express3[i,"tumor_stage"]="late"
	}
	if(final_express3[i,"tumor_stage"]==5)
	{
		final_express3[i,"tumor_stage"]="not_reported"
	}
	
	
}
###########################################准备矩阵数据#################################################################


###########################################计算训练集中每个样本的risk_score和risk_level#################################################################
#multi_res
train_express=final_express2[1:287,]
#train_express1=train_express[which(train_express[,"tumor_stage"] %in% c(1,2)),]	#162
train_express2=train_express[which(train_express[,"tumor_stage"] %in% c(3,4)),]	#125

train_express1=final_express2[30:191,]

score_express1=matrix(,nrow(train_express1),10)
score_express2=matrix(,nrow(train_express2),10)


rownames(score_express1)=rownames(train_express1)
colnames(score_express1)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")
score_express1[,1:8]=train_express1[,colnames(score_express1)[1:8]]

for(i in 1:nrow(score_express1))
{
	score_express1[i,"risk_score"]=(0.0126948)*score_express1[i,1]+(0.0011064)*score_express1[i,2]+(0.0018182)*score_express1[i,3]+
	(-0.0342018)*score_express1[i,4]+(0.0061149)*score_express1[i,5]+(-0.0299009)*score_express1[i,6]
}
cutt_off1=median(score_express1[,"risk_score"])
for(i in 1:nrow(score_express1))
{
	if(score_express1[i,"risk_score"]<=cutt_off1)
	{
		score_express1[i,"risk_level"]=0 
	}
	else
	{
		score_express1[i,"risk_level"]=1
	}
}


##计算训练集中样本的risk_level绘制生存曲线
score_express1=as.data.frame(score_express1)
fit_t1<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express1)
gg_t1=ggsurvplot(fit_t1, data = score_express1,
xlab = "Survival time (year)",
ylab = "Survival ratio",
#surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("low", "high"),
legend = c(0.8, 0.8),	#改变图例位置
pval = TRUE,
risk.table = TRUE,
tables.height = 0.34,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("train_KM_early.png", plot = print(gg_t1), width = 3.5, height = 3.6, units = "in")
##计算训练集中每个样本的risk_level绘制生存曲线



rownames(score_express2)=rownames(train_express2)
colnames(score_express2)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")
score_express2[,1:8]=train_express2[,colnames(score_express2)[1:8]]

for(i in 1:nrow(score_express2))
{
	score_express2[i,"risk_score"]=(0.0126948)*score_express2[i,1]+(0.0011064)*score_express2[i,2]+(0.0018182)*score_express2[i,3]+
	(-0.0342018)*score_express2[i,4]+(0.0061149)*score_express2[i,5]+(-0.0299009)*score_express2[i,6]
}

#cutt_off为risk_score的中位数
cutt_off2=median(score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(score_express2))
{
	if(score_express2[i,"risk_score"]<=cutt_off2)
	{
		score_express2[i,"risk_level"]=0 
	}
	else
	{
		score_express2[i,"risk_level"]=1
	}
}


##计算训练集中样本的risk_level绘制生存曲线
score_express2=as.data.frame(score_express2)
fit_t2<- survfit(Surv(os_time, vital_status) ~ risk_level, data = score_express2)
gg_t2=ggsurvplot(fit_t2, data = score_express2,
xlab = "Survival time (year)",
ylab = "Survival ratio",
#surv.median.line = "hv", # Add medians survival
legend.title = "Strata",
legend.labs = c("low", "high"),
legend = c(0.8, 0.8),	#改变图例位置
pval = TRUE,
risk.table = TRUE,
tables.height = 0.36,
#tables.theme = theme_cleantable(),
 palette = c("#0000FF", "#FF0000"),
 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("train_KM_late.png", plot = print(gg_t2), width = 3.5, height = 3.6, units = "in")
##计算训练集中每个样本的risk_level绘制生存曲线



#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
risk_dist=matrix(,nrow=nrow(train_express1),ncol=2)
risk_dist[,1]=c(1:nrow(train_express1))
risk_dist[,2]=sort(score_express1[,"risk_score"])
#plot(sort(score_express2[,"risk_score"]),ylab = "Risk score",)

z <- risk_dist[,1]
df <- data.frame(x = risk_dist[,1], y = risk_dist[,2], z = z)
#将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
p1=ggplot(data = df, mapping = aes(x = risk_dist[,1], y = risk_dist[,2], colour = z)) + 
			geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
			xlab("Patients (increasing risk score)") + 
			ylab("Risk score") + 
			theme_bw()+
			theme(panel.grid =element_blank(),
				axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
				axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
				axis.title.x = element_text(size = 9, color = "black"),
				axis.title.y = element_text(size = 9, color = "black")
			)+		#去除网格
			geom_vline(aes(xintercept=81), colour="#009600", linetype="dashed",size=1)+
			annotate("text", x=33.75, y=1, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
			annotate("text", x=114.75, y=1, label="High risk",alpha=.5,colour="darkred",size=3)+ 
			theme(legend.position="none")
ggsave(p1,filename = "train_risk_score_early.png",width = 2.3,height = 1.5)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_score_express=data.frame(score_express1[order(score_express1[,"risk_score"]),])
order_score_express$vital_status <- factor(order_score_express$vital_status)
p2=ggplot(data = order_score_express, mapping = aes(x = c(1:nrow(order_score_express)), y = os_time,
			colour = vital_status)) + 
			scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
			geom_point(size = 1,alpha=0.8)+
			labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
			theme_bw()+
			theme(panel.grid =element_blank(),
				axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
				axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
				axis.title.x = element_text(size = 9, color = "black"),
				axis.title.y = element_text(size = 9, color = "black")
			)+		#删除网格
			geom_vline(aes(xintercept=81), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
			annotate("text", x=33.75, y=9, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
			annotate("text", x=114.75, y=9, label="High risk",alpha=.5,colour="darkred",size=3)+
			#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
			#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
			theme(legend.position="none")
ggsave(p2,filename = "train_risk_score_os_early.png",width = 2.3,height = 1.8)


p3=ggpubr::ggarrange(p1,p2,labels = c("A", "B"),ncol=1)
ggsave(p3,filename = "train_risk_score_total_early.png",width = 5,height = 5)



risk_dist2=matrix(,nrow=nrow(train_express2),ncol=2)
risk_dist2[,1]=c(1:nrow(train_express2))
risk_dist2[,2]=sort(score_express2[,"risk_score"])
#plot(sort(score_express2[,"risk_score"]),ylab = "Risk score",)

z2 <- risk_dist2[,1]
df <- data.frame(x = risk_dist2[,1], y = risk_dist2[,2], z = z2)
#将连续变量映射给颜色属性		## face取值：plain普通，bold加粗，italic斜体，bold.italic斜体加粗
library(ggplot2)
p4=ggplot(data = df, mapping = aes(x = risk_dist2[,1], y = risk_dist2[,2], colour = z2)) + 
			geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
			xlab("Patients (increasing risk score)") + 
			ylab("Risk score") + 
			theme_bw()+
			theme(panel.grid =element_blank(),
				axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
				axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
				axis.title.x = element_text(size = 9, color = "black"),
				axis.title.y = element_text(size = 9, color = "black")
			)+		#去除网格
			geom_vline(aes(xintercept=62.5), colour="#009600", linetype="dashed",size=1)+
			annotate("text", x=26, y=1, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
			annotate("text", x=88.5, y=1, label="High risk",alpha=.5,colour="darkred",size=3)+ 
			theme(legend.position="none")
ggsave(p4,filename = "train_risk_score_late.png",width = 2.3,height = 1.5)

#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_score_express=data.frame(score_express2[order(score_express2[,"risk_score"]),])
order_score_express$vital_status <- factor(order_score_express$vital_status)
p5=ggplot(data = order_score_express, mapping = aes(x = c(1:nrow(order_score_express)), y = os_time,
			colour = vital_status)) + 
			scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
			geom_point(size = 1,alpha=0.8)+
			labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
			theme_bw()+
			theme(panel.grid =element_blank(),
				axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
				axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
				axis.title.x = element_text(size = 9, color = "black"),
				axis.title.y = element_text(size = 9, color = "black")
			)+		#删除网格
			geom_vline(aes(xintercept=62.5), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
			annotate("text", x=26, y=9, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
			annotate("text", x=88.5, y=9, label="High risk",alpha=.5,colour="darkred",size=3)+
			#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
			#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
			theme(legend.position="none")
ggsave(p5,filename = "train_risk_score_os_late.png",width = 2.3,height = 1.8)


p6=ggpubr::ggarrange(p4,p5,labels = c("A", "B"),ncol=1)
ggsave(p6,filename = "train_risk_score_total_late.png",width = 5,height = 5)


###########################################计算训练集中每个样本的risk_score和risk_level#################################################################



###########################################计算测试集中每个样本的risk_score和risk_level#################################################################
test_express=final_express2[288:411,]	#124
test_express1=test_express[which(test_express[,"tumor_stage"] %in% c(1,2)),]	#74
test_express2=test_express[which(test_express[,"tumor_stage"] %in% c(3,4)),]	#50
test_express1=test_express[22:95,]

test_score_express1=matrix(,nrow(test_express1),10)
rownames(test_score_express1)=rownames(test_express1)
colnames(test_score_express1)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")
test_score_express1[,1:8]=test_express1[,colnames(test_score_express1)[1:8]]

for(i in 1:nrow(test_score_express1))
{
	test_score_express1[i,"risk_score"]=(0.0126948)*test_score_express1[i,1]+(0.0011064)*test_score_express1[i,2]+(0.0018182)*test_score_express1[i,3]+
	(-0.0342018)*test_score_express1[i,4]+(0.0061149)*test_score_express1[i,5]+(-0.0299009)*test_score_express1[i,6]
}

#cutt_off为risk_score的中位数
cutt_off_t1=median(test_score_express1[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express1))
{
	if(test_score_express1[i,"risk_score"]<=cutt_off_t1)
	{
		test_score_express1[i,"risk_level"]=0 
	}
	else
	{
		test_score_express1[i,"risk_level"]=1
	}
}



test_score_express2=matrix(,nrow(test_express2),10)
rownames(test_score_express2)=rownames(test_express2)
colnames(test_score_express2)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")

test_score_express2[,1:8]=test_express2[,colnames(test_score_express2)[1:8]]

for(i in 1:nrow(test_score_express2))
{
	test_score_express2[i,"risk_score"]=(0.0126948)*test_score_express2[i,1]+(0.0011064)*test_score_express2[i,2]+(0.0018182)*test_score_express2[i,3]+
	(-0.0342018)*test_score_express2[i,4]+(0.0061149)*test_score_express2[i,5]+(-0.0299009)*test_score_express2[i,6]
}

#cutt_off为risk_score的中位数
cutt_off_t2=median(test_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(test_score_express2))
{
	if(test_score_express2[i,"risk_score"]<=cutt_off_t2)
	{
		test_score_express2[i,"risk_level"]=0 
	}
	else
	{
		test_score_express2[i,"risk_level"]=1
	}
}



##计算测试集中每个样本的risk_level绘制生存曲线
test_score_express1=as.data.frame(test_score_express1)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express1)
t_gg1=ggsurvplot(fit, data = test_score_express1,
		xlab = "Survival time (year)",
		ylab = "Survival ratio",
		#surv.median.line = "hv", # Add medians survival
		legend.title = "Strata",
		legend.labs = c("low", "high"),
		legend = c(0.8, 0.8),	#改变图例位置
		pval = TRUE,
		risk.table = TRUE,
		tables.height = 0.34,
		#tables.theme = theme_cleantable(),
		 palette = c("#0000FF", "#FF0000"),
		 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("test_KM_early.png", plot = print(t_gg1), width = 3.5, height = 3.6, units = "in")



test_score_express2=as.data.frame(test_score_express2)
fit<- survfit(Surv(os_time, vital_status) ~ risk_level, data = test_score_express2)
t_gg2=ggsurvplot(fit, data = test_score_express2,
		xlab = "Survival time (year)",
		ylab = "Survival ratio",
		#surv.median.line = "hv", # Add medians survival
		legend.title = "Strata",
		legend.labs = c("low", "high"),
		legend = c(0.8, 0.8),	#改变图例位置
		pval = TRUE,
		risk.table = TRUE,
		tables.height = 0.34,
		#tables.theme = theme_cleantable(),
		 palette = c("#0000FF", "#FF0000"),
		 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("test_KM_late.png", plot = print(t_gg2), width = 3.5, height = 3.6, units = "in")


#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
library(ggplot2)
t_p1=ggplot(data = test_score_express1, mapping = aes(x = c(1:nrow(test_score_express1)), y = sort(test_score_express1[,"risk_score"]),
					colour = c(1:nrow(test_score_express1)))) + 
				geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
				xlab("Patients (increasing risk score)") + 
				ylab("Risk score") + 
				theme_bw()+
				theme(panel.grid =element_blank(),
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+		#删除网格
				geom_vline(aes(xintercept=37), colour="#009600", linetype="dashed",size=1)+
				annotate("text", x=15, y=2.801974, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=52, y=2.801974, label="High risk",alpha=.5,colour="darkred",size=3)+ 
				theme(legend.position="none")
ggsave(t_p1,filename = "test_risk_score_early.png",width = 2.3,height = 1.5)




#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(test_score_express1[order(test_score_express1[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
t_p2=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
				colour = vital_status)) + 
				scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
				geom_point(size = 1,alpha=0.8)+
				labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
				theme_bw()+
				theme(panel.grid =element_blank(),		#删除网格
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+
				geom_vline(aes(xintercept=37), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
				annotate("text", x=15, y=9.6, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=52, y=9.6, label="High risk",alpha=.5,colour="darkred",size=3)+
				#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
				#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
				theme(legend.position="none")
ggsave(t_p2,filename = "test_risk_score_os_early.png",width = 2.3,height = 1.8)
				
t_p3=ggpubr::ggarrange(t_p1,t_p2,labels = c("A", "B"),ncol=1)
ggsave(t_p3,filename = "test_risk_score_total_early.png",width = 5,height = 5)




t_p4=ggplot(data = test_score_express2, mapping = aes(x = c(1:nrow(test_score_express2)), y = sort(test_score_express2[,"risk_score"]),
					colour = c(1:nrow(test_score_express2)))) + 
				geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
				xlab("Patients (increasing risk score)") + 
				ylab("Risk score") + 
				theme_bw()+
				theme(panel.grid =element_blank(),
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+		#删除网格
				geom_vline(aes(xintercept=25), colour="#009600", linetype="dashed",size=1)+
				annotate("text", x=10, y=2.801974, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=35, y=2.801974, label="High risk",alpha=.5,colour="darkred",size=3)+ 
				theme(legend.position="none")
ggsave(t_p4,filename = "test_risk_score_late.png",width = 2.3,height = 1.5)




#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(test_score_express2[order(test_score_express2[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
t_p5=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
				colour = vital_status)) + 
				scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
				geom_point(size = 1,alpha=0.8)+
				labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
				theme_bw()+
				theme(panel.grid =element_blank(),		#删除网格
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+
				geom_vline(aes(xintercept=25), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
				annotate("text", x=10, y=7.6, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=35, y=7.6, label="High risk",alpha=.5,colour="darkred",size=3)+
				#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
				#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
				theme(legend.position="none")
ggsave(t_p5,filename = "test_risk_score_os_late.png",width = 2.3,height = 1.8)
				
t_p6=ggpubr::ggarrange(t_p4,t_p5,labels = c("A", "B"),ncol=1)
ggsave(t_p6,filename = "test_risk_score_total_late.png",width = 5,height = 5)
###########################################计算测试集中每个样本的risk_level绘制生存曲线#################################################################




###########################################计算total集中每个样本的risk_score和risk_level#################################################################
total_express=final_express2	#124
total_express1=total_express[which(total_express[,"tumor_stage"] %in% c(1,2)),]	#236
total_express2=total_express[which(total_express[,"tumor_stage"] %in% c(3,4)),]	#175
total_express1=total_express[172:407,]


total_score_express1=matrix(,nrow(total_express1),10)
rownames(total_score_express1)=rownames(total_express1)
colnames(total_score_express1)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")
total_score_express1[,1:8]=total_express1[,colnames(total_score_express1)[1:8]]

for(i in 1:nrow(total_score_express1))
{
	total_score_express1[i,"risk_score"]=(0.0126948)*total_score_express1[i,1]+(0.0011064)*total_score_express1[i,2]+(0.0018182)*total_score_express1[i,3]+
	(-0.0342018)*total_score_express1[i,4]+(0.0061149)*total_score_express1[i,5]+(-0.0299009)*total_score_express1[i,6]
}

#cutt_off为risk_score的中位数
cutt_off_total1=median(total_score_express1[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(total_score_express1))
{
	if(total_score_express1[i,"risk_score"]<=cutt_off_total1)
	{
		total_score_express1[i,"risk_level"]=0 
	}
	else
	{
		total_score_express1[i,"risk_level"]=1
	}
}



total_score_express2=matrix(,nrow(total_express2),10)
rownames(total_score_express2)=rownames(total_express2)
colnames(total_score_express2)=c("ENSG00000259347.4","ENSG00000228437.4","ENSG00000253405.1","ENSG00000271797.1",
"ENSG00000166770.9","ENSG00000264016.2",
"os_time","vital_status","risk_score","risk_level")

total_score_express2[,1:8]=total_express2[,colnames(total_score_express2)[1:8]]

for(i in 1:nrow(total_score_express2))
{
	total_score_express2[i,"risk_score"]=(0.0126948)*total_score_express2[i,1]+(0.0011064)*total_score_express2[i,2]+(0.0018182)*total_score_express2[i,3]+
	(-0.0342018)*total_score_express2[i,4]+(0.0061149)*total_score_express2[i,5]+(-0.0299009)*total_score_express2[i,6]
}

#cutt_off为risk_score的中位数
cutt_off_total2=median(total_score_express2[,"risk_score"])

#根据cutt_off计算risk_level,1代表低风险，2代表高风险
for(i in 1:nrow(total_score_express2))
{
	if(total_score_express2[i,"risk_score"]<=cutt_off_total2)
	{
		total_score_express2[i,"risk_level"]=0 
	}
	else
	{
		total_score_express2[i,"risk_level"]=1
	}
}



##计算测试集中每个样本的risk_level绘制生存曲线
total_score_express1=as.data.frame(total_score_express1)
total_fit1<- survfit(Surv(os_time, vital_status) ~ risk_level, data = total_score_express1)
total_gg1=ggsurvplot(total_fit1, data = total_score_express1,
		xlab = "Survival time (year)",
		ylab = "Survival ratio",
		#surv.median.line = "hv", # Add medians survival
		legend.title = "Strata",
		legend.labs = c("low", "high"),
		legend = c(0.8, 0.8),	#改变图例位置
		pval = TRUE,
		risk.table = TRUE,
		tables.height = 0.34,
		#tables.theme = theme_cleantable(),
		 palette = c("#0000FF", "#FF0000"),
		 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("total_KM_early.png", plot = print(total_gg1), width = 3.5, height = 3.6, units = "in")



total_score_express2=as.data.frame(total_score_express2)
total_fit2<- survfit(Surv(os_time, vital_status) ~ risk_level, data = total_score_express2)
total_gg2=ggsurvplot(total_fit2, data = total_score_express2,
		xlab = "Survival time (year)",
		ylab = "Survival ratio",
		#surv.median.line = "hv", # Add medians survival
		legend.title = "Strata",
		legend.labs = c("low", "high"),
		legend = c(0.8, 0.8),	#改变图例位置
		pval = TRUE,
		risk.table = TRUE,
		tables.height = 0.34,
		#tables.theme = theme_cleantable(),
		 palette = c("#0000FF", "#FF0000"),
		 #ggtheme = theme_bw() # Change ggplot2 theme
 )
ggsave("total_KM_late.png", plot = print(total_gg2), width = 3.5, height = 3.6, units = "in")


#绘制risk_score的分布图，横坐标为样本数，纵坐标为risk_score值
library(ggplot2)
total_p1=ggplot(data = total_score_express1, mapping = aes(x = c(1:nrow(total_score_express1)), y = sort(total_score_express1[,"risk_score"]),
					colour = c(1:nrow(total_score_express1)))) + 
				geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
				xlab("Patients (increasing risk score)") + 
				ylab("Risk score") + 
				theme_bw()+
				theme(panel.grid =element_blank(),
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+		#删除网格
				geom_vline(aes(xintercept=118), colour="#009600", linetype="dashed",size=1)+
				annotate("text", x=49, y=1.26, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=167, y=1.26, label="High risk",alpha=.5,colour="darkred",size=3)+ 
				theme(legend.position="none")
ggsave(total_p1,filename = "total_risk_score_early.png",width = 2.3,height = 1.5)




#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(total_score_express1[order(total_score_express1[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
total_p2=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
				colour = vital_status)) + 
				scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
				geom_point(size = 1,alpha=0.8)+
				labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
				theme_bw()+
				theme(panel.grid =element_blank(),		#删除网格
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+
				geom_vline(aes(xintercept=118), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
				annotate("text", x=49, y=9.6, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=167, y=9.6, label="High risk",alpha=.5,colour="darkred",size=3)+
				#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
				#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
				theme(legend.position="none")
ggsave(total_p2,filename = "total_risk_score_os_early.png",width = 2.3,height = 1.8)
				
total_p3=ggpubr::ggarrange(total_p1,total_p2,labels = c("A", "B"),ncol=1)
ggsave(total_p3,filename = "total_risk_score_total_early.png",width = 5,height = 5)




total_p4=ggplot(data = total_score_express2, mapping = aes(x = c(1:nrow(total_score_express2)), y = sort(total_score_express2[,"risk_score"]),
					colour = c(1:nrow(total_score_express2)))) + 
				geom_point(size = 1.5) +scale_colour_gradient(low = 'blue', high = 'red')+
				xlab("Patients (increasing risk score)") + 
				ylab("Risk score") + 
				theme_bw()+
				theme(panel.grid =element_blank(),
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+		#删除网格
				geom_vline(aes(xintercept=87.5), colour="#009600", linetype="dashed",size=1)+
				annotate("text", x=36.5, y=2.801974, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=124, y=2.801974, label="High risk",alpha=.5,colour="darkred",size=3)+ 
				theme(legend.position="none")
ggsave(total_p4,filename = "total_risk_score_late.png",width = 2.3,height = 1.5)




#绘制样本的risk_score和os_time的关系图，横坐标为样本数，纵坐标为生存时间值
order_test1_score_express=data.frame(total_score_express2[order(total_score_express2[,"risk_score"]),])
order_test1_score_express$vital_status <- factor(order_test1_score_express$vital_status)
total_p5=ggplot(data = order_test1_score_express, mapping = aes(x = c(1:nrow(order_test1_score_express)), y = os_time,
				colour = vital_status)) + 
				scale_color_manual(values=c("blue","red"),labels = c("Alive", "Dead"))+	#对默认给定的颜色进行修改
				geom_point(size = 1,alpha=0.8)+
				labs(x = "Patients (increasing risk score)", y = "Survival time (year)", title="")+
				theme_bw()+
				theme(panel.grid =element_blank(),		#删除网格
					axis.text.x = element_text(size = 7, color = "black", vjust = 0.8, hjust = 0.5, angle = 0),
					axis.text.y = element_text(size = 7, color = "black", vjust = 0.5, hjust = 0.5, angle = 0),
					axis.title.x = element_text(size = 9, color = "black"),
					axis.title.y = element_text(size = 9, color = "black")
				)+
				geom_vline(aes(xintercept=87.5), colour="#009600", linetype="dashed",size=0.9)+	#画一条竖线
				annotate("text", x=36.5, y=9.6, label="Low risk",alpha=.5,colour="darkblue",size=3)+ 
				annotate("text", x=124, y=9.6, label="High risk",alpha=.5,colour="darkred",size=3)+
				#theme(legend.position=c(.89, .75),legend.key=element_rect(fill="white",color="black",size=0.5),
				#legend.title=element_blank(),legend.margin=margin(t = 0, unit='cm'),legend.text=element_text(size=5))
				theme(legend.position="none")
ggsave(total_p5,filename = "total_risk_score_os_late.png",width = 2.3,height = 1.8)
				
total_p6=ggpubr::ggarrange(total_p4,total_p5,labels = c("A", "B"),ncol=1)
ggsave(total_p6,filename = "total_risk_score_total_late.png",width = 5,height = 5)
###########################################计算total集中每个样本的risk_level绘制生存曲线#################################################################








